using System;
using System.Collections.Generic;
using System.Text;

namespace AgendaProject.Agenda
{
	public class INFORMATII
	{
		string SIR;
	}
}
