using System;
using System.Collections.Generic;
using System.Text;

namespace AgendaProject.Agenda
{
	public class TIMPCEAS
	{
		int ore;
		int minute;
		int secunde;
	}
}
