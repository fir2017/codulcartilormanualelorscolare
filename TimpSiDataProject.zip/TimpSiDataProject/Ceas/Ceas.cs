using System;
using System.Collections.Generic;
using System.Text;

namespace TimpSiDataProject.Ceas
{
	public class Ceas
	{
		Data data;
	}
}
