using System;
using System.Collections.Generic;
using System.Text;

namespace TimpSiDataProject.Calendar
{
	public enum ZileleSaptamanii
	{
		Luni,
		Marti,
		Miercuri,
		Joi,
		Vineri,
		Sambata,
		Duminica
	}
}
