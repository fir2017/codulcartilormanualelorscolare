using System;
using System.Collections.Generic;
using System.Text;

namespace TimpSiDataProject.Calendar
{
	public enum LunileAnului
	{
		Ianuarie,
		Februarie,
		Martie,
		Aprilie,
		Mai,
		Iunie,
		Iulie,
		August,
		Septembrie,
		Octombrie,
		Noiembrie,
		Decembrie
	}
}
