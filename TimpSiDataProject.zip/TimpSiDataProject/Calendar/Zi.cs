using System;
using System.Collections.Generic;
using System.Text;

namespace TimpSiDataProject.Calendar
{
	public class Zi
	{
		Data data;
	}
}
