using System;
using System.Collections.Generic;
using System.Text;

namespace TimpSiDataProject.AgendaPersonala
{
	public class AnulLuni
	{
		List <Luna> lunileanului;
	}
}
