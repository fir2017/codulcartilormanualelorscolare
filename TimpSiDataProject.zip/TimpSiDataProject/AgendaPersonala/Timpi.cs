using System;
using System.Collections.Generic;
using System.Text;

namespace TimpSiDataProject.AgendaPersonala
{
	public class Timpi
	{
		Timp timp;
		Informatie informatie;
	}
}
