using System;
using System.Collections.Generic;
using System.Text;

namespace TimpSiDataProject.AgendaPersonala
{
	public class Saptamana
	{
		List < Ziua > zile;
	}
}
