using System;
using System.Collections.Generic;
using System.Text;

namespace TimpSiDataProject.Data
{
	public class Data
	{
		int an;
		int luna;
		int zi;
	}
}
