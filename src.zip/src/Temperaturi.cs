

int namx = 31;
List <int > T = new List<int>();
int nrp;
int nrs = 0;
int i;
for(i=0;i<31;i++) T.Add(i);
nrp = T[0]>0?1:0;
for(i=1;i<31;i++)
{if(t[i]>0) nrp++;
if(T[i-1]*T[i]<0) nrs++;}

Text = nrp + " " + nrs ;

