
#include <iostream.h>
int main()
{
	long int n , start , x, i ;
	cin >> n;
	if(n<5 || n*(n+1)%3){cout << " nu exista solutie " ; return 0;}
	if(!((n-9(%6)){start = 10; x=(n-9)/6;}
	if(!((n-8(%6)){start = 9; x=(n-8)/6;}
	if(!((n-6(%6)){start = 7; x=(n-6)/6;}
	if(!((n-4(%6)){start = 6; x=(n-5)/6;}
	switch(start)
	{case 10: cout<<"1 2 3 4 5"; break;
	case 9: cout<<"1 2 3 6"; break;
	case 7: cout<<"3 4"; break;
	case 6: cout<<"5"<<' '; break;}
	for(i=0;i<x;i++) cout<<start + 6 * i << ' ' << start + 5 + 6*i<<' ';
	cout<<endl;
	switch(start)
	{case 10: cout<<7<<''<<8<<' '; break;
	case 9: cout<<5<<''<<7<<' '; break;
	case 7: cout<<2<<''<<5<<' '; break;
	case 6: cout<<2<<''<<3<<' '; break;}
	for(i=0;i<x;i++) cout<<start + 1+ 6 * i << ' ' << start + 4 + 6*i<<' ';
	cout<<endl;
	switch(start)
	{case 10: cout<<6<<''<<9<<' '; break;
	case 9: cout<<4<<''<<8<<' '; break;
	case 7: cout<<1<<''<<6<<' '; break;
	case 6: cout<<1<<''<<4<<' '; break;}
	for(i=0;i<x;i++) cout<<start + 2 + 6 * i << ' ' << start + 3 + 6*i<<' ';
	cout<<endl;
	return 0;
	}
	