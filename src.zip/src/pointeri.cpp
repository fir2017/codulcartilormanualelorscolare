 
 
 referentiere 
 &variabila
 
 dereferentiere
*variabilapointer;
 
 int i = 10, *p;
 p = &i;
 cout<<*p;
 
 afisare pointer
 cout << p;
 
 