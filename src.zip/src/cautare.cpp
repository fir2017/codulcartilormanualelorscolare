

cautare secventiala

for(gasit = i = 0 ; i<n && !gasit; i++)
	if(a[i]==x) gasit = 1;



cautare binara 

for(st = 0, dr = n-1, gasit = 0 ; !gasit && st<=dr; )
{mijloc = (st+dr)/2;
if(a[mijloc]==x) gasit = 1;
else 
	if(a[mijloc]>x) st = mijloc + 1;
else dr = mijloc-1;}
if(gasit ) cout << x << " se gaseste pe pozitia " << mijloc ;
else caut << x << " nu se afla in vector ";


sortare prin selectie 

for(dr =n -1; dr > 0 ; dr--)
{for(max = 1[0], pozmax=0, i=1; i<=dr ; i++)
	 if(a[i]>max) max = a[i], pozmax = i;
  a[pozmax]=a[dr];
  a[dr] = max;
}

bubble sort

do{
	schimb =0;
	for(i=0; i<n-1; i++)
		 if(a[i] >a[i+1])
		 {
			 aux =a[i];
			 a[i] = a[i+1];
			 a[i+1]=aux;
		 schimb=1;}
}
while(schimb};


sortare prin selectie 


for(i=1; i<n l i++)
{v = a[i];
for(poz=i;poz && a[poz-1]>v;poz--)
	a[poz] = a[poz-1];
a[poz]=v;
}



counting sort


#define max 1000
#define nrmax 10000

int n , v[max],a[nrmax];
int main()
{
	intx,i,j,nr;
	cout << "n="; cin >> n;
	for(i=0;i<n;i++)
	{ cin >> x;
	v[x]++;}
	for(nr=i=0;i<max ; i++)
		 for(j=0;j<v[i];j++)
			 a[nr++]=i;
		 for(i=0;i<n;i++)
			 cout<<a[i]<<' ';
		 cout << endl;
		 return 0;
}



interclasare sort

for(i=j=k=0;i<n && j<m;)
if (a[i]<b[j])
//copiez in c
c[k++]=a[i++];
else
c[k++]=b[j++];
//copiez eventualele elemente rarnase in a
for(;i<n;i++)
c[k++]=a[i] ;
//copiez eventualele elemente rarnase in b
for(;j<m;j++)
c[k++]=b[j};



afisare inserare matrice 

 for(i=0;i<n;i++){
	  for(j=0;j<m;j++){
		  m[i][j];
	  }
 }
 
 
 parcurgere matice pe linie 


for(i=0;i<n;i++){
	  for(s=0,j=0;j<m;j++){
 s+=a[i][j];
	  }
}
 
 parcurgere pe coloane
 
 for(j=0;j<m;i++){
	  for(s=0,i=0;j<n;j++){
  s+=a[i][j];
	  }
 }
 
 
 
 afisare elemente pe diagonala principala
 
 for(i=0;i<n;i++){ cout<< a[i][i]<<' ';}
 
 afisare elemente pe diagonala secundara
 
 for(i=0;i<n;i++){ cout<< a[i][n-i-1]<<' ';}
	  
  
  parcurgere elemente de subdiagonala principala
  
  for(s=0,i=1;i<n;i++){
	  for(j=0;j<i;j++){
  s+=a[i][j];
	  }
 }
  
  
 








