
 struct Punct
 {double x, y;}
 
 struct Elev
 {char nume[30], adr[60];
 float medii[14], mg;
 unsigned long tel;
 }
 clasa [30];
 
 
 struct data{
	 int zi, an;
	 char luna[15];
 }
 
 struct data azi = {31,2004,"decembrie"};
 
 
 
 
 