using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Admitere
{
	public enum TipComanda
	{
		Inscriere,
		Modificare,
		Retragere,
		Note,
		Ordonare,
		Afisare,
		Terminare
	}
}
