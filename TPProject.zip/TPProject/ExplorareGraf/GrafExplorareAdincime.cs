using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.ExplorareGraf
{
	public class GrafExplorareAdincime
	{
		List <STIVAADINCIME> STIVA;
		List <NMAXNODURI> VIZITATE;

		public void EXPLORAREADINCIME()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
