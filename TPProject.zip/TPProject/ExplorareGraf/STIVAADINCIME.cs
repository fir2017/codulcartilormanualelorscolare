using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.ExplorareGraf
{
	public class STIVAADINCIME
	{
		public void INITIALIZARESTIVAI()
		{
			throw new NotImplementedException();
		}

		public void INTRODUCEINSTIVAI()
		{
			throw new NotImplementedException();
		}

		public void EXTRAGEDINSTIVAI()
		{
			throw new NotImplementedException();
		}

		public void TESTSTIVAGOALAI()
		{
			throw new NotImplementedException();
		}

		public void VALOAREDINVARFI()
		{
			throw new NotImplementedException();
		}
	}
}
