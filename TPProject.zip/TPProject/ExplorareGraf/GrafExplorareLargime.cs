using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.ExplorareGraf
{
	public class GrafExplorareLargime
	{
		List <COADALARGIME> COADA;
		List <NMAXNODURI> VIZITATE;

		public void EXPLORAREINLARGIME()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
