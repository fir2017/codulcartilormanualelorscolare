using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Coada
{
	public class ElementCoada
	{
		SIR nume;
		Element urmatorul;
	}
}
