using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Coada
{
	public class CoadaDinamica
	{
		Element CapulCozii;
		Element CoadaCozii;
	}
}
