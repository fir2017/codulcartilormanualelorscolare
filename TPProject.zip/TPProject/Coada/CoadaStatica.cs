using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Coada
{
	public class CoadaStatica
	{
		int CapulCozii;
		int CoadaCozii;
		int LungimeCoada;
		List <Element> elemente;

		public void INITIALIZARECOADA()
		{
			throw new NotImplementedException();
		}

		public void TESTCOADAGOALA()
		{
			throw new NotImplementedException();
		}

		public void INTRODUCEINCOADA()
		{
			throw new NotImplementedException();
		}

		public void EXTRAGEDINCOADA()
		{
			throw new NotImplementedException();
		}

		public void VALOAREDINCAP()
		{
			throw new NotImplementedException();
		}

		public void AVANS()
		{
			throw new NotImplementedException();
		}

		public void LISTEAZACOADA()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
