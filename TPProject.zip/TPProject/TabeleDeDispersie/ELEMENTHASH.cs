using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.TabeleDeDispersie
{
	public class ELEMENTHASH
	{
		int POZITIEINVECTOR;
		ELEMENTHASH URMATORUL;
	}
}
