using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Sortare
{
	public class SORT
	{
		List <ELEMENTSORT> X;
		int NRE;
		SIR NUME;

		public void CITESTEVALORI()
		{
			throw new NotImplementedException();
		}

		public void LISTEAZAVALORI()
		{
			throw new NotImplementedException();
		}

		public void LISTEAZACHEI()
		{
			throw new NotImplementedException();
		}

		public void SCHIMBA()
		{
			throw new NotImplementedException();
		}

		public void BUBBLESORT()
		{
			throw new NotImplementedException();
		}

		public void INSERTSORT()
		{
			throw new NotImplementedException();
		}

		public void INSERTSORTMODIF()
		{
			throw new NotImplementedException();
		}

		public void SELECTSORT()
		{
			throw new NotImplementedException();
		}

		public void QUICKSORT()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
