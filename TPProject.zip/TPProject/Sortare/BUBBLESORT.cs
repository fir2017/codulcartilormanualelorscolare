using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Sortare
{
	public class BUBBLESORT
	{
		int NF;
		int I;
		int U;

		public BUBBLESORT(ELEMENTSORT PX, int N)
		{
			throw new NotImplementedException();
		}
	}
}
