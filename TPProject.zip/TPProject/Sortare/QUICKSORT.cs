using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Sortare
{
	public class QUICKSORT
	{
		int J;
		ELEMENTSORT PIVOT;

		public QUICKSORT(ELEMENTSORT PX, int PRIMUL, int ULTIMUL)
		{
			throw new NotImplementedException();
		}
	}
}
