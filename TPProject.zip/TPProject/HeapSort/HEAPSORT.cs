using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.HeapSort
{
	public class HEAPSORT
	{
		int NRELEM;
		List <Element> X;
		int N;

		public void SCHIMBA()
		{
			throw new NotImplementedException();
		}

		public void PROPAG()
		{
			throw new NotImplementedException();
		}

		public void HEAPSORT()
		{
			throw new NotImplementedException();
		}
	}
}
