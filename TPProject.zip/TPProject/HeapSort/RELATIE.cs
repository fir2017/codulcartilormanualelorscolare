using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.HeapSort
{
	public class RELATIE
	{
	}
}
