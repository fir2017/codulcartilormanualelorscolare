using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Grafuri
{
	public class GRAF
	{
		List <Element> CAP;
		List <Element> LEGATURI;
		int NNODURI;
		int NLEGATURI;

		public void AFLALEGATURAURMATOARE()
		{
			throw new NotImplementedException();
		}

		public void AFLANOD()
		{
			throw new NotImplementedException();
		}

		public void AFLACAP()
		{
			throw new NotImplementedException();
		}

		public void AFLALEGATURA()
		{
			throw new NotImplementedException();
		}

		public void CITESTEGRAF()
		{
			throw new NotImplementedException();
		}
	}
}
