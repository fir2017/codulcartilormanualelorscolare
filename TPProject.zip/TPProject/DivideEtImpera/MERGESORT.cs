using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.DivideEtImpera
{
	public class MERGESORT
	{
		int MAXIM;
		int[] A;
		int I;
		int N;
		int[] BUF;

		public void AFISARE()
		{
			throw new NotImplementedException();
		}

		public void COMBINARE()
		{
			throw new NotImplementedException();
		}

		public void SORTARE()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
