using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Canale
{
	public class CANAL
	{
		int INCEPUT;
		int SFARSIT;
		POZITIE POZITIECANAL;
		bool FIXAT;
	}
}
