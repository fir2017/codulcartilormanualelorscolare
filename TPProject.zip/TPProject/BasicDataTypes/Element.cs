using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.BasicDataTypes
{
	public class Element
	{
		object data;
	}
}
