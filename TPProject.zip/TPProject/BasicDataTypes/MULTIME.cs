using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.BasicDataTypes
{
	public class MULTIME
	{
		public void INITMULTIMEVIDA()
		{
			throw new NotImplementedException();
		}

		public void EXTRAGEELEMENT()
		{
			throw new NotImplementedException();
		}

		public void APARTINE()
		{
			throw new NotImplementedException();
		}

		public void ADAUGAELEMENT()
		{
			throw new NotImplementedException();
		}

		public void APARTINE()
		{
			throw new NotImplementedException();
		}
	}
}
