using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Editor
{
	public class POZITIE
	{
		int x;
		int y;
	}
}
