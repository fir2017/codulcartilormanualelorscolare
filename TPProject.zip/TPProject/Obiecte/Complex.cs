using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Obiecte
{
	public class Complex
	{
		float real;
		float imaginar;
	}
}
