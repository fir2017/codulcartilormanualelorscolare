using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Obiecte
{
	public class Masina
	{
		SIR marca;
		DATA AnFabricatie;
		CULORI Culoarea;
		bool Functioneaza;

		public void ACEASIMASINA()
		{
			throw new NotImplementedException();
		}

		public void CITESTEMASINA()
		{
			throw new NotImplementedException();
		}
	}
}
