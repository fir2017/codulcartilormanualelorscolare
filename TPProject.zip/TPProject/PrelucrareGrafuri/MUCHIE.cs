using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.PrelucrareGrafuri
{
	public class MUCHIE
	{
		int COST;
		int NOD1;
		int NOD2;
	}
}
