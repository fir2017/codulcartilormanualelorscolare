using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.PrelucrareGrafuri
{
	public class ADINCNRC
	{
		Lista <int > VIZITATE;
		Lista <int > APEL;
		Lista <int > IESIRE;
		int CONTOR1;
		int CONTOR2;

		public void EXPLORARERECURSIVA1()
		{
			throw new NotImplementedException();
		}

		public void MAIN()
		{
			throw new NotImplementedException();
		}
	}
}
