using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Biblioteca
{
	public class Biblioteca
	{
		CoadaDinamica Coada;
		SIR nume;
		int Main;
	}
}
