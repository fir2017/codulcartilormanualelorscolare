using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Lista
{
	public class ListaStatica
	{
		int curent;
		int sfarsit;
		List <Element> elemente;

		public void INITIALIZARELISTA()
		{
			throw new NotImplementedException();
		}

		public void TESTLISTAVIDA()
		{
			throw new NotImplementedException();
		}

		public void POZITIONAREINCEPUT()
		{
			throw new NotImplementedException();
		}

		public void POZITIONARESFARSIT()
		{
			throw new NotImplementedException();
		}

		public void TESTINCEPUT()
		{
			throw new NotImplementedException();
		}

		public void TESTSFARSIT()
		{
			throw new NotImplementedException();
		}

		public void URMATORUL()
		{
			throw new NotImplementedException();
		}

		public void PRECEDENT()
		{
			throw new NotImplementedException();
		}

		public void ADAUGALASFARSIT()
		{
			throw new NotImplementedException();
		}

		public void ADRESAINFORMATIE()
		{
			throw new NotImplementedException();
		}

		public void MODIFICAINFORMATIE()
		{
			throw new NotImplementedException();
		}

		public void STERGEELEMENT()
		{
			throw new NotImplementedException();
		}

		public void INSEREAZAELEMENT()
		{
			throw new NotImplementedException();
		}

		public void LUNGIMELISTA()
		{
			throw new NotImplementedException();
		}
	}
}
