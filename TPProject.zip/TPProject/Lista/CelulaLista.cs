using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Lista
{
	public class CelulaLista
	{
		Element element;
		celula prec;
		celula urm;
	}
}
