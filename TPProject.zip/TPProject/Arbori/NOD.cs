using System;
using System.Collections.Generic;
using System.Text;

namespace TPProject.Arbori
{
	public class NOD
	{
		Element inf;
		NOD st;
		NOD dr;
	}
}
