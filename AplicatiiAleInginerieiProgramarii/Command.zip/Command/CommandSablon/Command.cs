using System;
using System.Collections.Generic;
using System.Text;

namespace Command.CommandSablon
{
	public class Command
	{
		public void Execute()
		{
			throw new NotImplementedException();
		}
	}
}
