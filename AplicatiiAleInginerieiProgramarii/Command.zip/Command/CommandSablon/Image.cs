using System;
using System.Collections.Generic;
using System.Text;

namespace Command.CommandSablon
{
	public class Image
	{
		public void Cut()
		{
			throw new NotImplementedException();
		}

		public void FlipHorizontal()
		{
			throw new NotImplementedException();
		}

		public void FlipVertical()
		{
			throw new NotImplementedException();
		}

		public void Paste()
		{
			throw new NotImplementedException();
		}

		public void Resize()
		{
			throw new NotImplementedException();
		}

		public void Rotate()
		{
			throw new NotImplementedException();
		}
	}
}
