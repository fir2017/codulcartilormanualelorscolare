using System;
using System.Collections.Generic;
using System.Text;

namespace Command.CommandSablon
{
	public class FlipCommand : Command
	{
		Image _image;
		FlipStyle _style;

		public void FlipCommand()
		{
			throw new NotImplementedException();
		}

		public void Execute()
		{
			throw new NotImplementedException();
		}
	}
}
