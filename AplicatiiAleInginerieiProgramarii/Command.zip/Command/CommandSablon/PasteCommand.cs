using System;
using System.Collections.Generic;
using System.Text;

namespace Command.CommandSablon
{
	public class PasteCommand : Command
	{
		Document _document;

		public void PasteCommand()
		{
			throw new NotImplementedException();
		}

		public void Execute()
		{
			throw new NotImplementedException();
		}

		public void SelectPasteOptions()
		{
			throw new NotImplementedException();
		}
	}
}
