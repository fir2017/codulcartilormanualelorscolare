using System;
using System.Collections.Generic;
using System.Text;

namespace Command.SampleExcelCommand
{
	public class Client
	{
		Receiver r;
		Command c;
		Invoker i;

		public static void Main(string [] args)
		{
			throw new NotImplementedException();
		}
	}
}
