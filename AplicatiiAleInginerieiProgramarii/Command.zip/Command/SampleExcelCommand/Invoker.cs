using System;
using System.Collections.Generic;
using System.Text;

namespace Command.SampleExcelCommand
{
	public class Invoker
	{
		private Command _command;

		public void SetCommand(command Command)
		{
			throw new NotImplementedException();
		}

		public void ExecuteCommand()
		{
			throw new NotImplementedException();
		}
	}
}
