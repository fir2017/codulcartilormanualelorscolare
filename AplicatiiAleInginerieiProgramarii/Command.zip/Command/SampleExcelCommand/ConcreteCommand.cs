using System;
using System.Collections.Generic;
using System.Text;

namespace Command.SampleExcelCommand
{
	public class ConcreteCommand : Command
	{
		public ConcreteCommand(Receiver receive)
		{
			throw new NotImplementedException();
		}

		public override void Execute()
		{
			throw new NotImplementedException();
		}
	}
}
