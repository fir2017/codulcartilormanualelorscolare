using System;
using System.Collections.Generic;
using System.Text;

namespace Command.SampleExcelCommand
{
	public class Receiver
	{
		public void Action()
		{
			throw new NotImplementedException();
		}
	}
}
