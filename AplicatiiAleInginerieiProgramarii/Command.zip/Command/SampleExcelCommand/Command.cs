using System;
using System.Collections.Generic;
using System.Text;

namespace Command.SampleExcelCommand
{
	public abstract class Command
	{
		Receiver _receiver;

		protected Command(Receiver receiver)
		{
			throw new NotImplementedException();
		}

		public abstract void Execute();
	}
}
