using System;
using System.Collections.Generic;
using System.Text;

namespace Command.CommandPattern
{
	public class Receiver
	{
	}
}
