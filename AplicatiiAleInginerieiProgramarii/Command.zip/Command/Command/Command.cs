using System;
using System.Collections.Generic;
using System.Text;

namespace Command
{
	public class Command
	{
		public void Execute()
		{
			throw new NotImplementedException();
		}

		public void Undo()
		{
			throw new NotImplementedException();
		}

		public void Redo()
		{
			throw new NotImplementedException();
		}
	}
}
