using System;
using System.Collections.Generic;
using System.Text;

namespace Command.ComandaMacro
{
	public class MacroCommand : Command
	{
		Command [] _commands;

		public void Execute()
		{
			throw new NotImplementedException();
		}
	}
}
