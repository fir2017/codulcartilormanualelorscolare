using System;
using System.Collections.Generic;
using System.Text;

namespace Command.ComandaMacro
{
	public class Command
	{
		public void Execute()
		{
			throw new NotImplementedException();
		}
	}
}
