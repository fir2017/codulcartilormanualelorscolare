using System;
using System.Collections.Generic;
using System.Text;

namespace ZileProject.Zilele
{
	public class ZileTest
	{
		public void Test_04_07_2003()
		{
			throw new NotImplementedException();
		}
	}
}
