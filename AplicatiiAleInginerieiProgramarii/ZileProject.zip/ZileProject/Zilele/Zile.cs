using System;
using System.Collections.Generic;
using System.Text;

namespace ZileProject.Zilele
{
	public class Zile
	{
		int _zi;
		int _luna;
		int _an;
		int _diferenta;

		public int Diferenta
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public Zile(int zi, int luna, int an)
		{
			throw new NotImplementedException();
		}

		public void Calculeaza()
		{
			throw new NotImplementedException();
		}
	}
}
