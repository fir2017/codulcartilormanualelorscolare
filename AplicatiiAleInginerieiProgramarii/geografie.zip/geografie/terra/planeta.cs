using System;
using System.Collections.Generic;
using System.Text;

namespace geografie.terra
{
	public class planeta
	{
		List<continent> continente;
		List <ocean> oceane;
		string denumire;
	}
}
