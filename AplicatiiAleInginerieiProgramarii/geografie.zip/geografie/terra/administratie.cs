using System;
using System.Collections.Generic;
using System.Text;

namespace geografie.terra
{
	public class administratie
	{
		int nrlocuitori;
		string denumire;
		Imagine steag;
		pozitiegeografica pozitiageografica;
		string indicativ;
		string adresa;
	}
}
