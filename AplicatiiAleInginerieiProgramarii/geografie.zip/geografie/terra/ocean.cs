using System;
using System.Collections.Generic;
using System.Text;

namespace geografie.terra
{
	public class ocean
	{
		pozitiegeografica pozitiageografica;
		string denumire;
	}
}
