using System;
using System.Collections.Generic;
using System.Text;

namespace geografie.terra
{
	public class continent
	{
		List <tari> tari;
		pozitiegeografica pozitiageografica;
		string denumire;
	}
}
