using System;
using System.Collections.Generic;
using System.Text;

namespace geografie.relief
{
	public class formaderelief
	{
		string denumire;
		pozitiegeografica pozitiageografica;
		stil stilul;
		dimensiune dimensiunea;
		pozitie pozitia;
	}
}
