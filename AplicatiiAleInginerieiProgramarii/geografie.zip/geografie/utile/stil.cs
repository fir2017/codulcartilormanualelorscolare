using System;
using System.Collections.Generic;
using System.Text;

namespace geografie.utile
{
	public class stil
	{
		Color culoare;
		Color backgroundcolor;
		Color foregroundcolor;
		Font fontul;
	}
}
