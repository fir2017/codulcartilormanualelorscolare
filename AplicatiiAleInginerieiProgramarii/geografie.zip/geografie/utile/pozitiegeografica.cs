using System;
using System.Collections.Generic;
using System.Text;

namespace geografie.utile
{
	public class pozitiegeografica
	{
		pozitiegeografica3pozitii latitudine;
		pozitiegeografica3pozitii longitudine;
	}
}
