using System;
using System.Collections.Generic;
using System.Text;

namespace geografie.utile
{
	public class pozitiegeografica3pozitii
	{
		int grade;
		int minute;
		int secunde;
		int milisecunde;
		string simbol;
		string caracterdespartitor;
	}
}
