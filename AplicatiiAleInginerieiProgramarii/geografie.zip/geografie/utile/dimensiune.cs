using System;
using System.Collections.Generic;
using System.Text;

namespace geografie.utile
{
	public class dimensiune
	{
		float latime;
		float lungime;
		float inaltime;
		float adancime;
	}
}
