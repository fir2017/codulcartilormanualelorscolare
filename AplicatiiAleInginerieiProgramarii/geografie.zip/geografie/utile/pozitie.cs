using System;
using System.Collections.Generic;
using System.Text;

namespace geografie.utile
{
	public class pozitie
	{
		float x;
		float y;
		float z;
	}
}
