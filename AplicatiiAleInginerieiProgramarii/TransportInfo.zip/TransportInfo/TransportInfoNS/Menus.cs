using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public class Menus
	{
		int UserChoice;
		int MenuState;
		int MenuOption;

		public void MainMenu(List <MenuOption > options, string action)
		{
			throw new NotImplementedException();
		}

		public void AdminMenu(List <MenuOption > options, string action)
		{
			throw new NotImplementedException();
		}

		public void UserMenu(List <MenuOption > options, string action)
		{
			throw new NotImplementedException();
		}
	}
}
