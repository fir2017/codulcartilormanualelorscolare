using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public class Presenter : IPresenter
	{
		Model _model;
		IView _view;

		public Presenter(IView view, IModel model)
		{
			throw new NotImplementedException();
		}
	}
}
