using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public class BusinessCalculator
	{
		public static double Distance(City c1, City c2)
		{
			throw new NotImplementedException();
		}

		public static double Cost(double distance)
		{
			throw new NotImplementedException();
		}
	}
}
