using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public interface IView
	{
		void DIsplay(string text, string color);

		void SetPresenter(IPresenter presenter);
	}
}
