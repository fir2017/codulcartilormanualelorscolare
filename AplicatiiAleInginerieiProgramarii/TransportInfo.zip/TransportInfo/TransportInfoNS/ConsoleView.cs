using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public class ConsoleView : IView
	{
		IPresenter _presenter;
		IModel _model;
		List < MenuOption > _menuOptions;

		public ConsoleView(IModel model)
		{
			throw new NotImplementedException();
		}

		public void Start()
		{
			throw new NotImplementedException();
		}

		public UserChoice GetMenu(MenuState menuType)
		{
			throw new NotImplementedException();
		}

		public void GetTwoCities(string cityName1, string cityName2)
		{
			throw new NotImplementedException();
		}

		public string GetCity()
		{
			throw new NotImplementedException();
		}

		public City InputCity()
		{
			throw new NotImplementedException();
		}

		public void ListAll()
		{
			throw new NotImplementedException();
		}
	}
}
