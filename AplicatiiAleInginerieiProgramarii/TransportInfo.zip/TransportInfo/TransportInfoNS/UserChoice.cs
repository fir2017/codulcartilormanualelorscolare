using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public enum UserChoice
	{
		AdminMenu,
		UserMenu,
		PreviousMenu,
		Route,
		AdCity,
		RemoveCity,
		Exit,
		List,
		Undefined
	}
}
