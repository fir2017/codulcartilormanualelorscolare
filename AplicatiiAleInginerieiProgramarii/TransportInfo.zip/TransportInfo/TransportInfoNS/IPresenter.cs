using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public interface IPresenter
	{
		void AddCity(City c);

		bool CityExists(string name);

		void ComputeRoute(string city1, string city2);

		void Exit();

		City GetCity(string name);

		void Init();

		void RemoveCity(string name);
	}
}
