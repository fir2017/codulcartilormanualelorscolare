using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public enum MenuState
	{
		Main,
		Administrator,
		User
	}
}
