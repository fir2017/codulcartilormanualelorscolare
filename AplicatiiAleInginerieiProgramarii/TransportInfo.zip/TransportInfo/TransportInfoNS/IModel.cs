using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public interface IModel
	{
		bool Add(City city);

		int CityCount
		{
			get;
		}

		bool DataExists();

		bool Delete(string CityName);

		bool Exists(string cityName);

		void InitializeData();

		string ListAll();

		bool SaveData();

		City Search(string cityName);
	}
}
