using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public class Model : IModel
	{
		private string CityFileName;
		bool _wasModified;
		List <City> _cityList;

		public Model()
		{
			throw new NotImplementedException();
		}

		public int CityCount
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public int GetNumberOfCities()
		{
			throw new NotImplementedException();
		}

		public bool DataExists()
		{
			throw new NotImplementedException();
		}

		public void InitializeData()
		{
			throw new NotImplementedException();
		}

		public bool Add(City city)
		{
			throw new NotImplementedException();
		}

		public bool Delete(string cityName)
		{
			throw new NotImplementedException();
		}

		public bool Exists(string cityName)
		{
			throw new NotImplementedException();
		}

		public City Search(string cityName)
		{
			throw new NotImplementedException();
		}

		public string ListAll()
		{
			throw new NotImplementedException();
		}

		public bool SaveData()
		{
			throw new NotImplementedException();
		}

		private City ParseCity(string line)
		{
			throw new NotImplementedException();
		}
	}
}
