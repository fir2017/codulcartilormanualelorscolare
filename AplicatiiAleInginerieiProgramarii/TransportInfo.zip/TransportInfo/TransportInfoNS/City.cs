using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public struct City
	{
		readonly double Latitude;
		readonly double Longitude;
		readonly string Name;

		public City(string name, double latitude, double longitude)
		{
			throw new NotImplementedException();
		}
	}
}
