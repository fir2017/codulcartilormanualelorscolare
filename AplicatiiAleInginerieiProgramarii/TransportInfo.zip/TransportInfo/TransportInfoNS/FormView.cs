using System;
using System.Collections.Generic;
using System.Text;

namespace TransportInfo.TransportInfoNS
{
	public class FormView
	{
		IPresenter _Presenter;
		IModel _model;
		List < MenuOption > _menu1Options;
		List < MenuOption > _menu2Options;
		MenuState _menuState;

		public FormView()
		{
			throw new NotImplementedException();
		}

		public void SetModel(UserChoice menuState)
		{
			throw new NotImplementedException();
		}

		public void SetMenu(UseChoice choice)
		{
			throw new NotImplementedException();
		}

		public void ManageMenu()
		{
			throw new NotImplementedException();
		}

		public void EnableRouteFunction()
		{
			throw new NotImplementedException();
		}

		public void EnableAddCityFunction()
		{
			throw new NotImplementedException();
		}

		public void EnableRemoveCityFunction()
		{
			throw new NotImplementedException();
		}

		public void ListAll()
		{
			throw new NotImplementedException();
		}

		public void Load(object sender, EventArgs e)
		{
			throw new NotImplementedException();
		}
	}
}
