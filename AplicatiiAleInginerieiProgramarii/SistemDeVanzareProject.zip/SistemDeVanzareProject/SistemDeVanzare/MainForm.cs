using System;
using System.Collections.Generic;
using System.Text;

namespace SistemDeVanzareProject.SistemDeVanzare
{
	public class MainForm
	{
		public MainForm()
		{
			throw new NotImplementedException();
		}

		public void buttonComanda_Click()
		{
			throw new NotImplementedException();
		}

		public void buttonExit_Click()
		{
			throw new NotImplementedException();
		}

		public void buttonAbout_Click()
		{
			throw new NotImplementedException();
		}
	}
}
