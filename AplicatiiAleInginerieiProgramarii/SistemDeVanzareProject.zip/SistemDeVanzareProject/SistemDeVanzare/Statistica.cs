using System;
using System.Collections.Generic;
using System.Text;

namespace SistemDeVanzareProject.SistemDeVanzare
{
	public class Statistica
	{
		public string Afiseaza(Persoana pers)
		{
			throw new NotImplementedException();
		}
	}
}
