using System;
using System.Collections.Generic;
using System.Text;

namespace SistemDeVanzareProject.SistemDeVanzare
{
	public class Expediere
	{
		public string ExpediazaColet(Persoana pers, Adresa adr, double cost)
		{
			throw new NotImplementedException();
		}
	}
}
