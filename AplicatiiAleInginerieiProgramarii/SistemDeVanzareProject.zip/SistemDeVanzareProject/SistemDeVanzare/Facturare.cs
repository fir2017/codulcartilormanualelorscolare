using System;
using System.Collections.Generic;
using System.Text;

namespace SistemDeVanzareProject.SistemDeVanzare
{
	public class Facturare
	{
		double _cost;

		public double Cost
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public string EmiteFactura(string nume, List<int> produse)
		{
			throw new NotImplementedException();
		}
	}
}
