using System;
using System.Collections.Generic;
using System.Text;

namespace SistemDeVanzareProject.SistemDeVanzare
{
	public class ValidareCNP
	{
		public bool CNPValid(string cnp)
		{
			throw new NotImplementedException();
		}
	}
}
