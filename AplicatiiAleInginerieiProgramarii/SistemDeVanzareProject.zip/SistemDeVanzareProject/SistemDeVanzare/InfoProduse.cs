using System;
using System.Collections.Generic;
using System.Text;

namespace SistemDeVanzareProject.SistemDeVanzare
{
	public class InfoProduse
	{
		double _preturi;
		string _nume;

		public double PretProdus(int codProdus)
		{
			throw new NotImplementedException();
		}

		public string NumeProdus(int codProdus)
		{
			throw new NotImplementedException();
		}

		public int NumarProdus()
		{
			throw new NotImplementedException();
		}
	}
}
