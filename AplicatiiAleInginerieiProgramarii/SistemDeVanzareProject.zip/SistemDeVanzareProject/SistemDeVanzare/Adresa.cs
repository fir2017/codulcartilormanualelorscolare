using System;
using System.Collections.Generic;
using System.Text;

namespace SistemDeVanzareProject.SistemDeVanzare
{
	public class Adresa
	{
		string _strada;
		string _numar;
		string _oras;

		public Adresa(string strada, string numar, string oras)
		{
			throw new NotImplementedException();
		}

		public string Strada
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public string Numar
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public string Oras
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}
	}
}
