using System;
using System.Collections.Generic;
using System.Text;

namespace SistemDeVanzareProject.SistemDeVanzare
{
	public class Facade
	{
		Persoana _persoana;
		Adresa _adresa;
		List <int > _coduriProduse;

		public Facade(string prenume, string nume, string cnp, string strada, string numar, string oras, List<int> coduriProduse)
		{
			throw new NotImplementedException();
		}

		public string ProceseazaComanda()
		{
			throw new NotImplementedException();
		}

		public bool CNPValid(string cnp)
		{
			throw new NotImplementedException();
		}

		public string Produse()
		{
			throw new NotImplementedException();
		}
	}
}
