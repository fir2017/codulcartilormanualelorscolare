using System;
using System.Collections.Generic;
using System.Text;

namespace SistemDeVanzareProject.SistemDeVanzare
{
	public class Persoana
	{
		string _nume;
		string _prenume;
		string _cnp;

		public string Prenume
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public string Nume
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public string CNP
		{
			get
			{
				throw new NotImplementedException();
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		public Persoana(string persoana, string nume, string cnp)
		{
			throw new NotImplementedException();
		}
	}
}
