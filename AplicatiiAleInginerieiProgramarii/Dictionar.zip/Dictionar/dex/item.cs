using System;
using System.Collections.Generic;
using System.Text;

namespace Dictionar.dex
{
	public class item
	{
		Lista < cuvinte > tezaurdecuvinte;
		List < definite > definitii;
		List <explicatie > explicatii;
		galeriedeimagini imagini;
		List < text > texte;
	}
}
