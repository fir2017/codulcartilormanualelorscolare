using System;
using System.Collections.Generic;
using System.Text;

namespace Dictionar.dex
{
	public class galeriedeimagini
	{
		List < imagine > imagini;
	}
}
