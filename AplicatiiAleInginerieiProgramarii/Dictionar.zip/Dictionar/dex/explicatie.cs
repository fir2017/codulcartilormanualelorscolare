using System;
using System.Collections.Generic;
using System.Text;

namespace Dictionar.dex
{
	public class explicatie
	{
		definitie explicatia;
	}
}
