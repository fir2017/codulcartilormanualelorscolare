using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyDocumentsProject.ProxyDocuments
{
	public class EncryptedDocForm
	{
		RichTextBox richTextBox;

		public EncryptedDocForm(string encText)
		{
			throw new NotImplementedException();
		}
	}
}
