using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyDocumentsProject.ProxyDocuments
{
	public class ProxyDocumentManager : IDocumentManager
	{
		RealDocumentManager _realDocumentManager;
		List < User > _users;
		List < string > _levels;
		User _currentUser;
		const string Path = "Secure\\";
		EncryptedDocForm _encryptedDocForm;

		public List < string > Levels
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public int CurrentAccessLevel
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public ProxyDocumentManager()
		{
			throw new NotImplementedException();
		}

		public bool Login(string username, string password)
		{
			throw new NotImplementedException();
		}

		public List < string > GetDocumentList()
		{
			throw new NotImplementedException();
		}

		public string GetDocument(string documentName, string encryptionPassword)
		{
			throw new NotImplementedException();
		}

		public void AddUser(string user, string pass, int level)
		{
			throw new NotImplementedException();
		}

		public void SaveUsers()
		{
			throw new NotImplementedException();
		}
	}
}
