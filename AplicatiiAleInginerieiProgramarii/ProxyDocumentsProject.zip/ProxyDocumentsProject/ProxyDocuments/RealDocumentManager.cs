using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyDocumentsProject.ProxyDocuments
{
	public class RealDocumentManager : IDocumentManager
	{
		List < List < string >> _documents;
		const string Path = "Secure\\";
		const string DocPathj = "Secure\\Documente\\";
		int _currentLevel;

		public RealDocumentManager()
		{
			throw new NotImplementedException();
		}

		public RealDocumentManager(int accessLevel)
		{
			throw new NotImplementedException();
		}
	}
}
