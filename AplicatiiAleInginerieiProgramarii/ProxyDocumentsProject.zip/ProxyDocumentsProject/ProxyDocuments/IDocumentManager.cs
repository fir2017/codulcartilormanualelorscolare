using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyDocumentsProject.ProxyDocuments
{
	public interface IDocumentManager
	{
		List < string > GetDocumentList();

		string GetDocument(string documentName, string encryptionPassword);
	}
}
