using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyDocumentsProject.ProxyDocuments
{
	public struct User
	{
		public readonly string Name;
		public readonly string PassHash;
		public readonly int AccessLevel;

		public User(string name, string passHash, int accessLevel)
		{
			throw new NotImplementedException();
		}
	}
}
