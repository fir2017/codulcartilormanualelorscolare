using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyDocumentsProject.ProxyDocuments
{
	public class MainForm
	{
		ProxyDocumentManager _proxyDocumentManager;
	}
}
