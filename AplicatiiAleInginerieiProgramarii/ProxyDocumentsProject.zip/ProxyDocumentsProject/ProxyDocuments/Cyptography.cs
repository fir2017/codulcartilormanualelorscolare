using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyDocumentsProject.ProxyDocuments
{
	public class Cyptography
	{
		public string Encrypt(string text, string pass)
		{
			throw new NotImplementedException();
		}

		public string Decrypt(string text, string pass)
		{
			throw new NotImplementedException();
		}

		public string HashString(string str)
		{
			throw new NotImplementedException();
		}
	}
}
