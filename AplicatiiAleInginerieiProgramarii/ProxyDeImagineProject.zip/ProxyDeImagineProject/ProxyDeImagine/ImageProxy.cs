using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyDeImagineProject.ProxyDeImagine
{
	public class ImageProxy
	{
		Image _image;

		public void Draw()
		{
			throw new NotImplementedException();
		}

		public void Load()
		{
			throw new NotImplementedException();
		}

		public void GetSize()
		{
			throw new NotImplementedException();
		}
	}
}
