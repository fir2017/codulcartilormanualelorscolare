using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyDeImagineProject.ProxyDeImagine
{
	public class Image
	{
		Bitmap _data;

		public void Draw()
		{
			throw new NotImplementedException();
		}

		public void Load()
		{
			throw new NotImplementedException();
		}

		public void GetSize()
		{
			throw new NotImplementedException();
		}
	}
}
