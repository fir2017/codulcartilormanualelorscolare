using System;
using System.Collections.Generic;
using System.Text;

namespace ProxyDeImagineProject.ProxyDeImagine
{
	public class DocumentEditor
	{
		ImageProxy _image;

		public void DrawImages()
		{
			throw new NotImplementedException();
		}
	}
}
