public class AddingNumbers
{
public int AddTwo(int a, int b)
{
return a + b;
}
public int AddThree(int a, int b, int c)
{
return a + b + c;
}
}
class Program
{
static void Main(string[] args)
{
int x = 1, y = 2, z = 3;
AddingNumbers an =
new AddingNumbers();
int r1 = an.AddTwo(x, y);
Console.WriteLine(r1);
int r2 = an.AddThree(x, y, z);
Console.WriteLine(r2);
}
}