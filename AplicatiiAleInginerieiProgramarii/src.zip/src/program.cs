public class Program
{
static void Main(string[] args)
{
string[] s = new string[] { "Hello, ", "World!" };
for (int i = 0; i < s.Length; i++)
Console.Write(s[i]);
Console.WriteLine(Environment.NewLine + "ok"); // NewLine pentru Windows este "\r\n"
}
}