class OutExample
{
static void Method(out int i)
{
i = 44;
}
static void Main()
{
int val;
Method(out val);
// val este acum 44
}
}


void Change(ref MyPoint p, ref MyForm f)
{
p.X = 10;
// se modifică p1.X
f.Text = "Hello"; // se modifică f1.Text
f = null;
// f1 este distrus
}