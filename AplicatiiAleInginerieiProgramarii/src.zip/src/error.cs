

int a = 4;
int b = 3;
double c = 4;
bool ok = false;
Console.WriteLine(ok);




int b = 3;
double c = 4;
bool ok = false;
if (b < 3)
if (c > 3)
ok = true;
Console.WriteLine(ok);





if (true)
Console.WriteLine("ok");
if (false)
Console.WriteLine("false");
else
Console.WriteLine("true");
return;
Console.WriteLine("finished");


int a = 2 + 4 + 5;
double b = 9 / 5.0 + a + 9 + 5;
b++;






int b = 10;
if (b < 20)
{
Console.WriteLine("true");
}
else
{
goto After;
}
After:
Console.WriteLine("goto");
bool a = (b < 4);
if (a)
{
goto C;
}
Console.WriteLine(1);
C:
Console.WriteLine(2);













Test t = new Test();
int a = t.MyMethod();
Console.WriteLine(a);















int integer = 3;
double real = 3.14;
bool boolean = true;
Console.WriteLine("Integer: " + integer);
Console.WriteLine("Real: " + real);
Console.WriteLine("Boolean: " + boolean);
NumberForTestingOnly t = new NumberForTestingOnly();
Console.WriteLine("Test object: " + t.ReturnDouble(4));
public class NumberForTestingOnly
{
public int ReturnDouble(int par)
{
return par * 2;
}
}



























