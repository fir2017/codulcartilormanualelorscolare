abstract class Prototype
{
private string _data;public Prototype(string data)
{
_data = data;
}
public string Data
{
get
{
return _data;
}
}
abstract public Prototype Clone();
}

class ConcretePrototype1 : Prototype
{
public ConcretePrototype1(string data) : base(data)
{
}
override public Prototype Clone()
{
// copie superficială
return (Prototype)this.MemberwiseClone();
}
}
class ConcretePrototype2 : Prototype
{
public ConcretePrototype2(string data) : base(data)
{
}
override public Prototype Clone()
{
// copie superficială
return (Prototype)this.MemberwiseClone();
}
}





class Client
{
public static void Main(string[] args)
{
// se creează două prototipuri şi se clonează fiecare
ConcretePrototype1 prototype1 = new ConcretePrototype1("Proto1");
ConcretePrototype1 clone1 = (ConcretePrototype1)p1.Clone();
Console.WriteLine("Cloned: {0}", c1.Data);
ConcretePrototype2 prototype2 = new ConcretePrototype2("Proto2");
ConcretePrototype2 clone2 = (ConcretePrototype2)p2.Clone();
Console.WriteLine("Cloned: {0}", c2.Data);
Console.ReadLine();
}
}




