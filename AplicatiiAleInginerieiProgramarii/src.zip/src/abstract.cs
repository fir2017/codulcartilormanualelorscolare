public abstract class A
{
// membrii clasei
}


public abstract class A
{
public abstract void Method(int i);
}





interface IComparable
{
int CompareTo(object obj);
}





public class Minivan : Car, IComparable
{
public int CompareTo(object obj)
{
// implementarea metodei CompareTo
return 0; // dacă obiectele sunt egale
}
}






public class BaseClass
{
public virtual void Method()
{
...
}



public virtual int Property
{
get { ... }
}
}
public class DerivedClass : BaseClass
{
public override void Method()
{
...
}
public override int Property
{
get { ... }
}
}











DerivedClass B = new DerivedClass();
B.Method (); // Apelează metoda nouă
BaseClass A = (BaseClass)B;
A.Method (); // Apelează tot metoda nouă









public class A
{
public virtual void Method()
{
...
}
}




public sealed class A
{
// membrii clasei
}




















public class B
{
public virtual void Method()
{
...
}
}
public class C : B
{
public sealed override void Method()
{
...
}
}
















public class BaseClass
{
public void Method()
{
...
}
public int Property
{
get { ... }
}
}





















public class DerivedClass : BaseClass
{
public new void Method()
{
...
}
public new int Property
{
get { ... }
}
}

















DerivedClass B = new DerivedClass();
B.Method (); // Apelează metoda nouă
BaseClass A = (BaseClass)B;
A.Method (); // Apelează metoda veche

































public class A
{
public virtual void Method()
{
...
}
}
public class B : A
{
public override void Method()
{
...
}
}
public class C : B
{
public override void Method()
{
// apelează Method din B pentru a utiliza comportamentul lui B
base.Method();
// comportamentul specific lui C urmează în continuare
...
}
}






















if (openFileDialog.ShowDialog() != DialogResult.OK)
return;
































Document doc;
... // crearea obiectului document (creatorul concret)
tabControl.Controls.Clear();
foreach (Page p in doc.Pages)
{
TabPage tp = new TabPage(p.Name);
p.Content.Dock = DockStyle.Fill;
tp.Controls.Add(p.Content);
tabControl.TabPages.Add(tp);
}























_name = Path.GetFileNameWithoutExtension(fileName);
StreamReader sr = new StreamReader(indexFileName);
string line;
while ((line = sr.ReadLine()) != null)
{
if (line != string.Empty)
_pages.Add(CreatePage(line));
}
sr.Close();






















