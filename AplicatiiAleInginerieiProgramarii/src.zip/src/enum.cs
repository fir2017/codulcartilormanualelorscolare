enum Days { Sun, Mon, Tue, Wed, Thu, Fri, Sat };

enum Zile { Lun = 1, Mar, Mie, Joi, Vin, Sam, Dum };


int x = (int)Zile.Lun;
// x = 1
Zile z1 = Zile.Mar;
// z1 = Mar
Zile z2 = (Zile)3;
// z2 = Mie
string s = z2.ToString(); // s = "Mie"