MonsterSprite.cs
using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.Serialization;
namespace Monster
{
[Serializable]
public class MonsterSprite
{
protected Bitmap _image;
protected Color _color;
protected int _lives;
protected int _maxLives;
protected string _ai = "I am stupid";
public MonsterSprite(Monster settings)
{
_image = new Bitmap(settings.Image);
_maxLives = Convert.ToInt32(settings.Lives);
_lives = _maxLives;
_color = GetColor(settings.Color);
InitAI();
}
/// <summary>
/// Interpretează numele unei culori şi returnează un obiect Color
/// </summary>
/// <param name="colorName"></param>
/// <returns></returns>
protected Color GetColor(string colorName)
{
Color c;
switch (colorName)
{
case "red": c = Color.Red; break;
case "blue": c = Color.Blue; break;
case "green": c = Color.Green; break;
case "yellow": c = Color.Yellow; break;
case "orange": c = Color.Orange; break;
case "black": c = Color.Black; break;


default: c = Color.Gray; break;
}
return c;
}
private void InitAI()
{
_ai = "I am smart";
MessageBox.Show("Se initializeaza modulul de inteligenta artificiala...");
Thread.Sleep(2000);
}
/// <summary>
/// Desenează un personaj
/// </summary>
/// <param name="g"></param>
/// <param name="x"></param>
/// <param name="y"></param>
public void Draw(Graphics g, int x, int y)
{
g.DrawImage(_image, x, y);
double more = (double)_lives / (double)_maxLives;
g.FillRectangle(new SolidBrush(Color.DarkGray), (float)x, (float)(y + 200),
(float)200, (float)4);
g.FillRectangle(new SolidBrush(_color), (float)x, (float)(y + 200),
(float)(more * 200), (float)4);
}
/// <summary>
/// Returnează true dacă este mort
/// </summary>
/// <returns></returns>
public bool Shoot()
{
_lives--;
if (_lives == 0)
return true;
else
return false;
}
}
}






Utils.cs
namespace Monster
{
public class AllMonsters
{
public Monster[] Monsters;
}
public class Monster
{
public string Image;
public string Color;
public string Lives;
}
}





_mainMonster = new MonsterSprite(_listMonsters[_monsterType]);
cu:
_mainMonster = _prototypeManager.GetMonster(_monsterType);




public static object Clone(object obj)
{
object objClone = null;
MemoryStream memory = new MemoryStream();
BinaryFormatter binForm = new BinaryFormatter();
binForm.Serialize(memory, obj);
memory.Position = 0;
objClone = binForm.Deserialize(memory);
return objClone;
}























MainForm.cs
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
namespace Monster
{
public partial class MainForm : Form
{
List<Monster> _listMonsters;
MonsterSprite _mainMonster;
Random _rand = new Random();
int _monsterType = 0;
int _x, _y;
long _elapsed;
const int MonsterSize = 200;
const int MaxLevels = 4;
bool _gameOver = false;
public MainForm()
{
InitializeComponent();
}
private void loadSettingsToolStripMenuItem_Click(object sender, EventArgs e)
{
// încarcă
try
{
XmlSerializer serializer = new XmlSerializer(typeof(AllMonsters));
FileStream fs = new FileStream("settings.xml", FileMode.Open);
XmlReader reader = new XmlTextReader(fs);
AllMonsters ab = (AllMonsters)serializer.Deserialize(reader);
reader.Close(); fs.Close();
serializer = null;
_listMonsters = new List<Monster>();
for (int i = 0; i < ab.Monsters.Length; i++)
_listMonsters.Add(ab.Monsters[i]);
}
catch
{
MessageBox.Show("Nu s-a putut incarca settings.xml");
return;
}
if (_listMonsters == null || _listMonsters.Count == 0)
{
MessageBox.Show("Fisier de configurare invalid: settings.xml");
_listMonsters = null;
return;
}
}
private void startNewGameToolStripMenuItem_Click(object sender, EventArgs e)
{
// start
if (_listMonsters == null || _listMonsters.Count == 0)
loadSettingsToolStripMenuItem.PerformClick();
if (_listMonsters == null)
return;
_monsterType = 0;
_gameOver = false;
try
{
_mainMonster = new MonsterSprite(_listMonsters[_monsterType]);
}
catch (Exception exc)
{
MessageBox.Show(exc.Message);
_mainMonster = null;
return;
}




_elapsed = DateTime.Now.Ticks;
timer.Start();
Redraw();
}
private void Redraw()
{
try
{
_x = _rand.Next(pictureBox.Width - MonsterSize + 20);
_y = _rand.Next(pictureBox.Height - MonsterSize - 10);
pictureBox.Refresh();
}
catch
{
MessageBox.Show("Fereastra este prea mica");
_mainMonster = null;
return;
}
}
private void exitToolStripMenuItem_Click(object sender, EventArgs e)
{
Close();
}
private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
{
// despre program
const string copyright =
"Sablonul de proiectare Prototip\r\n" +
"Ingineria programarii\r\n" +
"(c) 2008-2012 Florin Leon\r\n" +
" http://florinleon.byethost24.com/lab_ip.htm ";
MessageBox.Show(copyright, "Despre Monstri");
}
private void pictureBox_Paint(object sender, PaintEventArgs e)
{
if (_mainMonster == null)
{
timer.Stop();


e.Graphics.Clear(Color.White);
if (_gameOver)
{
e.Graphics.DrawString("Jocul s-a terminat!", new Font("Arial", 48),
Brushes.Red, 10, 10);
long dt = DateTime.Now.Ticks - _elapsed;
double ms = dt / 10000000.0;
e.Graphics.DrawString(ms.ToString("F3") + " s", new Font("Arial", 48),
Brushes.Red, 10, 80);
}
return;
}
_mainMonster.Draw(e.Graphics, _x, _y);
}
private void ShootMonster()
{
if (_mainMonster.Shoot())
{
_monsterType++;
if (_monsterType < MaxLevels)
{
try
{
_mainMonster = new MonsterSprite(_listMonsters[_monsterType]);
}
catch (Exception exc)
{
MessageBox.Show(exc.Message);
_mainMonster = null;
return;
}
Redraw();
}
else
{
_mainMonster = null;
_gameOver = true;
pictureBox.Refresh();
}
}
else
Redraw();
}







private void pictureBox_MouseDown(object sender, MouseEventArgs e)
{
if (_mainMonster != null)
{
if (e.X > _x && e.X < _x + MonsterSize && e.Y > _y && e.Y < _y + MonsterSize)
ShootMonster();
}
}
private void timer_Tick(object sender, EventArgs e)
{
Graphics g = pictureBox.CreateGraphics();
long dt = DateTime.Now.Ticks - _elapsed;
double ms = dt / 10000000.0;
g.FillRectangle(Brushes.White, 1, 1, 100, 20);
g.DrawString(ms.ToString("F3") + " s", new Font("Arial", 10), Brushes.Black, 1, 1);
}
private void Form1_Load(object sender, EventArgs e)
{
this.WindowState = FormWindowState.Maximized;
}
}
}






settings.xml
<?xml version="1.0" encoding="us-ascii"?>
<AllMonsters>
<Monsters>
<Monster>
<Image>monster1.jpg</Image>
<Color>blue</Color>
<Lives>3</Lives>
</Monster>
<Monster>
<Image>monster2.jpg</Image>
<Color>green</Color>
<Lives>3</Lives>
</Monster>

<Monster>
<Image>monster3.jpg</Image>
<Color>black</Color>
<Lives>4</Lives>
</Monster>
<Monster>
<Image>monster4.jpg</Image>
<Color>red</Color>
<Lives>5</Lives>
</Monster>
</Monsters>
</AllMonsters>


