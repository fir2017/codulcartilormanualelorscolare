int i = 123;
object o = i;
int j = (int)o; // tip valoare (unboxing)