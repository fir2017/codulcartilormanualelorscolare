if (openFileDialog.ShowDialog() != DialogResult.OK) // nu s-a apăsat OK
return;











StreamWriter sw = new StreamWriter(saveFileDialog.FileName);
// operaţii cu sw
// de exemplu scriem în fişier un număr n cu 3 zecimale
sw.WriteLine("Numarul este {0:F3}", n);
sw.Close();















