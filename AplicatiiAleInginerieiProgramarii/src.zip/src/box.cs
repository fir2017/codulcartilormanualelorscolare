int i = 123; // tip valoare
object o = i; // tip referinţă (boxing)