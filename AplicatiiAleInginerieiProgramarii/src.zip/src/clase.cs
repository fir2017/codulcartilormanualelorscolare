public class ClassA
{
protected int _propInt;
public virtual void OperationA1(int a, out int b, ref int c)
{
}
public int OperationA2()
{
}
}
public class ClassB : ClassA
{
private int _propertyB1;
private ClassC _propertyB2;
public bool OperationB1()
{
}
}
public class ClassC
{
private double _propertyC;
public int OperationC()
{
}
public double PropertyC
{
set { }
get { }
}
}