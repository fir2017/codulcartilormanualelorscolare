


Subiectul abstract
abstract class Subject
{
// Metode
abstract public void Request();
}
Subiectul real
class RealSubject : Subject
{
// Metode
override public void Request()
{
Console.WriteLine("Apelul din subiectul real");
}
}
Proxy
class Proxy : Subject
{
RealSubject _realSubject;
override public void Request()
{
// Se foloseşte iniţializarea întârziată
if (_realSubject == null)
_realSubject = new RealSubject();realSubject.Request();
}
}
Clientul
public class Client
{
public static void Main(string[] args)
{
// Se creează un proxy şi se apelează metoda dorită
Proxy p = new Proxy();
p.Request();
}
}







_encryptedDocForm = new EncryptedDocForm(encryptedFile);
_encryptedDocForm.WindowState = FormWindowState.Minimized;
_encryptedDocForm.Show();






MainForm.cs
namespace ProtectionProxy
{
public partial class MainForm : Form
{
private ProxyDocumentManager _proxyDocumentManager;
public MainForm()
{
InitializeComponent();
groupBoxAdmin.Enabled = false;
_proxyDocumentManager = new ProxyDocumentManager();
}
}
}
DocumentManager.cs
namespace ProtectionProxy
{
interface IDocumentManager
{
List<string> GetDocumentList();
string GetDocument(string documentName, string encryptionPassword);
}
}
ProxyDocumentManager.cs
namespace ProtectionProxy
{
public class ProxyDocumentManager : IDocumentManager
{
private RealDocumentManager _realDocumentManager;
private List<User> _users;




private List<string> _levels;
private const string Path = "Secure\\";
public struct User
{
public readonly string Name;
public readonly string PassHash;
public readonly int AccessLevel;
public User(string name, string passHash, int accessLevel)
{
Name = name;
PassHash = passHash;
AccessLevel = accessLevel;
}
}
public ProxyDocumentManager()
{
_levels = new List<string>();
StreamReader sr = new StreamReader(Path + "niveluri.txt");
string[] lvls = sr.ReadToEnd().Split(" \t\r\n".ToCharArray(),
StringSplitOptions.RemoveEmptyEntries);
sr.Close();
for (int i = 0; i < lvls.Length; i++)
_levels.Add(lvls[i]);
_users = new List<User>();
sr = new StreamReader(Path + "utilizatori.txt");
string line;
while ((line = sr.ReadLine()) != null)
{
string[] toks = line.Split('\t');
User user = new User(toks[0], toks[1], Convert.ToInt32(toks[2]));
_users.Add(user);
}
sr.Close();
}
#region IDocumentManager Members
public List<string> GetDocumentList()
{
throw new Exception("The method or operation is not implemented.");
}





public string GetDocument(string documentName, string encryptionPassword)
{
throw new Exception("The method or operation is not implemented.");
}
#endregion
}
}
RealDocumentManager.cs
namespace ProtectionProxy
{
class RealDocumentManager : IDocumentManager
{
private static List<List<string>> _documents;
private const string Path = "Secure\\", DocPath = "Secure\\Documente\\";
static RealDocumentManager()
{
int numberOfLevels = 0;
StreamReader sr = new StreamReader(Path + "drepturi.txt");
string[] lines = sr.ReadToEnd().Split("\r\n".ToCharArray(),
StringSplitOptions.RemoveEmptyEntries);
sr.Close();
numberOfLevels = lines.Length;
_documents = new List<List<string>>(numberOfLevels);
for (int i = 0; i < numberOfLevels; i++)
_documents.Add(new List<string>());
sr = new StreamReader(Path + "drepturi.txt");
for (int i = 0; i < numberOfLevels; i++)
{
string[] files = sr.ReadLine().Split();
for (int j = i; j < numberOfLevels; j++)
{
for (int k = 0; k < files.Length; k++)
_documents[j].Add(files[k]);
}
}
sr.Close();
}






#region IDocumentManager Members
public List<string> GetDocumentList()
{
throw new Exception("The method or operation is not implemented.");
}
public string GetDocument(string documentName, string encryptionPassword)
{
throw new Exception("The method or operation is not implemented.");
}
#endregion
}
}









Cryptography.cs
/**************************************************************************
* Website: http://www.obviex.com/samples/Encryption.aspx *
* Adaptation and added functionality by Florin Leon *
* http://florinleon.byethost24.com/lab_ip.htm *
* Description: Contains functions for encryption, decryption, *
* and hashing. *
**************************************************************************/
using System;
using System.Security.Cryptography;
using System.IO;
using System.Text;

namespace ProtectionProxy
{
public class Cryptography
{
/// <summary>
/// Encrypts specified plaintext using Rijndael symmetric key algorithm
/// and returns a base64-encoded result.
/// </summary>
/// <param name="plainText">
/// Plaintext value to be encrypted.
/// </param>
/// <param name="passPhrase">
/// Passphrase from which a pseudo-random password will be derived. The
/// derived password will be used to generate the encryption key.
/// Passphrase can be any string. In this example we assume that this
/// passphrase is an ASCII string.
/// </param>
/// <param name="saltValue">
/// Salt value used along with passphrase to generate password. Salt can
/// be any string. In this example we assume that salt is an ASCII string.
/// </param>
/// <param name="hashAlgorithm">
/// Hash algorithm used to generate password. Allowed values are: "MD5" and
/// "SHA1". SHA1 hashes are a bit slower, but more secure than MD5 hashes.
/// </param>
/// <param name="passwordIterations">
/// Number of iterations used to generate password. One or two iterations
/// should be enough.
/// </param>
/// <param name="initVector">
/// Initialization vector (or IV). This value is required to encrypt the
/// first block of plaintext data. For RijndaelManaged class IV must be
/// exactly 16 ASCII characters long.
/// </param>
/// <param name="keySize">
/// Size of encryption key in bits. Allowed values are: 128, 192, and 256.
/// Longer keys are more secure than shorter keys.
/// </param>
/// <returns>
/// Encrypted value formatted as a base64-encoded string.
/// </returns>
public static string Encrypt(string text, string pass)
{
string plainText = text;
string passPhrase = pass;
string saltValue = "s@1tValue"; // can be any string


string hashAlgorithm = "SHA1";// can be "MD5"
int passwordIterations = 2; // can be any number
string initVector = "@1B2c3D4e5F6g7H8"; // must be 16 bytes
int keySize = 256; // can be 192 or 128
// Convert strings into byte arrays.
// Let us assume that strings only contain ASCII codes.
// If strings include Unicode characters, use Unicode, UTF7, or UTF8
// encoding.
byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);
// Convert our plaintext into a byte array.
// Let us assume that plaintext contains UTF8-encoded characters.
byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
// First, we must create a password, from which the key will be derived.
// This password will be generated from the specified passphrase and
// salt value. The password will be created using the specified hash
// algorithm. Password creation can be done in several iterations.
PasswordDeriveBytes password = new PasswordDeriveBytes(
passPhrase,
saltValueBytes,
hashAlgorithm,
passwordIterations);
// Use the password to generate pseudo-random bytes for the encryption
// key. Specify the size of the key in bytes (instead of bits).
byte[] keyBytes = password.GetBytes(keySize / 8);
// Create uninitialized Rijndael encryption object.
RijndaelManaged symmetricKey = new RijndaelManaged();
// It is reasonable to set encryption mode to Cipher Block Chaining
// (CBC). Use default options for other symmetric key parameters.
symmetricKey.Mode = CipherMode.CBC;
// Generate encryptor from the existing key bytes and initialization
// vector. Key size will be defined based on the number of the key
// bytes.
ICryptoTransform encryptor = symmetricKey.CreateEncryptor(
keyBytes,
initVectorBytes);
// Define memory stream which will be used to hold encrypted data.
MemoryStream memoryStream = new MemoryStream();



// Define cryptographic stream (always use Write mode for encryption).
CryptoStream cryptoStream = new CryptoStream(memoryStream,
encryptor,
CryptoStreamMode.Write);
// Start encrypting.
cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
// Finish encrypting.
cryptoStream.FlushFinalBlock();
// Convert our encrypted data from a memory stream into a byte array.
byte[] cipherTextBytes = memoryStream.ToArray();
// Close both streams.
memoryStream.Close();
cryptoStream.Close();
// Convert encrypted data into a base64-encoded string.
string cipherText = Convert.ToBase64String(cipherTextBytes);
// Return encrypted string.
return cipherText;
}
/// <summary>
/// Decrypts specified ciphertext using Rijndael symmetric key algorithm.
/// </summary>
/// <param name="cipherText">
/// Base64-formatted ciphertext value.
/// </param>
/// <param name="passPhrase">
/// Passphrase from which a pseudo-random password will be derived. The
/// derived password will be used to generate the encryption key.
/// Passphrase can be any string. In this example we assume that this
/// passphrase is an ASCII string.
/// </param>
/// <param name="saltValue">
/// Salt value used along with passphrase to generate password. Salt can
/// be any string. In this example we assume that salt is an ASCII string.
/// </param>
/// <param name="hashAlgorithm">
/// Hash algorithm used to generate password. Allowed values are: "MD5" and
/// "SHA1". SHA1 hashes are a bit slower, but more secure than MD5 hashes.
/// </param>
/// <param name="passwordIterations">
/// Number of iterations used to generate password. One or two iterations


/// should be enough.
/// </param>
/// <param name="initVector">
/// Initialization vector (or IV). This value is required to encrypt the
/// first block of plaintext data. For RijndaelManaged class IV must be
/// exactly 16 ASCII characters long.
/// </param>
/// <param name="keySize">
/// Size of encryption key in bits. Allowed values are: 128, 192, and 256.
/// Longer keys are more secure than shorter keys.
/// </param>
/// <returns>
/// Decrypted string value.
/// </returns>
/// <remarks>
/// Most of the logic in this function is similar to the Encrypt
/// logic. In order for decryption to work, all parameters of this function
/// - except cipherText value - must match the corresponding parameters of
/// the Encrypt function which was called to generate the
/// ciphertext.
/// </remarks>
public static string Decrypt(string text, string pass)
{
string cipherText = text;
string passPhrase = pass;
string saltValue = "s@1tValue"; // can be any string
string hashAlgorithm = "SHA1";// can be "MD5"
int passwordIterations = 2; // can be any number
string initVector = "@1B2c3D4e5F6g7H8"; // must be 16 bytes
int keySize = 256; // can be 192 or 128
// Convert strings defining encryption key characteristics into byte
// arrays. Let us assume that strings only contain ASCII codes.
// If strings include Unicode characters, use Unicode, UTF7, or UTF8
// encoding.
byte[] initVectorBytes = Encoding.ASCII.GetBytes(initVector);
byte[] saltValueBytes = Encoding.ASCII.GetBytes(saltValue);
// Convert our ciphertext into a byte array.
byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
// First, we must create a password, from which the key will be
// derived. This password will be generated from the specified
// passphrase and salt value. The password will be created using
// the specified hash algorithm. Password creation can be done in
// several iterations.






PasswordDeriveBytes password = new PasswordDeriveBytes(
passPhrase,
saltValueBytes,
hashAlgorithm,
passwordIterations);
// Use the password to generate pseudo-random bytes for the encryption
// key. Specify the size of the key in bytes (instead of bits).
byte[] keyBytes = password.GetBytes(keySize / 8);
// Create uninitialized Rijndael encryption object.
RijndaelManaged symmetricKey = new RijndaelManaged();
// It is reasonable to set encryption mode to Cipher Block Chaining
// (CBC). Use default options for other symmetric key parameters.
symmetricKey.Mode = CipherMode.CBC;
// Generate decryptor from the existing key bytes and initialization
// vector. Key size will be defined based on the number of the key
// bytes.
ICryptoTransform decryptor = symmetricKey.CreateDecryptor(
keyBytes,
initVectorBytes);
// Define memory stream which will be used to hold encrypted data.
MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
// Define cryptographic stream (always use Read mode for encryption).
CryptoStream cryptoStream = new CryptoStream(memoryStream,
decryptor,
CryptoStreamMode.Read);
// Since at this point we don't know what the size of decrypted data
// will be, allocate the buffer long enough to hold ciphertext;
// plaintext is never longer than ciphertext.
byte[] plainTextBytes = new byte[cipherTextBytes.Length];
// Start decrypting.
int decryptedByteCount = cryptoStream.Read(plainTextBytes,
0,
plainTextBytes.Length);
// Close both streams.
memoryStream.Close();
cryptoStream.Close();


// Convert decrypted data into a string.
// Let us assume that the original plaintext string was UTF8-encoded.
string plainText = Encoding.UTF8.GetString(plainTextBytes,
0,
decryptedByteCount);
// Return decrypted string.
return plainText;
}
/// <summary>
/// Returns the hash of a string
/// </summary>
/// <param name="str"></param>
/// <returns></returns>
public static string HashString(string str)
{
HashAlgorithm sha = new SHA1CryptoServiceProvider();
byte[] buf = new byte[str.Length];
for (int i = 0; i < str.Length; i++)
buf[i] = (byte)str[i];
byte[] result = sha.ComputeHash(buf);
return Convert.ToBase64String(result);
}
}
}



