Clasa Singleton
class Singleton
{
private static Singleton _instance;
private int _data; // datele propriu-zise ale clasei
public int Data
{
get { return _data; }
set { _data = value; }
}
private Singleton() // protected dacă avem nevoie de clase derivate
{
}
public static Singleton Instance()
{
// Iniţializare întârziată ("lazy initialization")
if( _instance == null )
_instance = new Singleton();
return _instance;
}
}
Clientul
public class Client
{
public static void Main()
{
// constructorul este privat, nu se poate folosi "new"
Singleton s1 = Singleton.Instance();
s1.Data = 5;
Singleton s2 = Singleton.Instance();
Console.WriteLine("Rezultat: {0}", s2.Data); // "Rezultat: 5"
Console.ReadLine();
}
}

