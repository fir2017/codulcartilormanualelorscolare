MyPoint p1; // p1 este alocat cu valorile implicite ale membrilor
p1 = new MyPoint(); // nu are efect aici, resetează valorile membrilor
MyForm f1; // se alocă referinţa, f1 = null
f1 = new MyForm(); // se alocă obiectul, f1 primeşte referinţa acestuia

MyPoint p2 = p1;
MyForm f2 = f1;

void Change(MyPoint p, MyForm f)
{
p.X = 10;
// p este o copie, instrucţiunea nu are efect asupra lui p1
f.Text = "Hello"; // f şi f1 pointează la acelaşi obiect, f1.Text se schimbă
f = null; // f este o copie a referinţei f1, instrucţiunea nu are efect asupra lui f1
}