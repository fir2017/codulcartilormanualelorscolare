double a = Matematica.Putere.Patrat(5.5);


// se încearcă încărcarea DLL-ului
Assembly a = Assembly.Load("Operatii");
// se identifică tipul (clasa) care trebuie instanţiată
// dacă în clasa din DLL există un namespace,
// se foloseşte numele complet al clasei din assembly, incluzând namespace-ul
Type t = a.GetType("Matematica.Putere");
// se identifică metoda care ne interesează
MethodInfo mi = t.GetMethod("Patrat");





// se creează o instanţă a clasei dorite
// aici se apelează constructorul implicit
object o = Activator.CreateInstance(t);
// definim un vector de argumente pentru a fi trimis metodei
// metoda Pătrat are numai un argument de tip double
object[] args = new object[1];
double x = 5.5;
args[0] = x;
// apelul efectiv al metodei şi memorarea rezultatului
double result = (double)mi.Invoke(o, args);






private void Form1_Load(object sender, EventArgs e)
{
try
{
LoadOperatiiPutere();
}
catch (Exception exc)
{
MessageBox.Show(exc.Message, "Exceptie DLL");
Close();
}
}







private void LoadOperatiiPutere()
{
Type t = null;
try
{
Assembly a = Assembly.Load("Operatii");
t = a.GetType("Matematica.Putere");
}
catch (Exception)
{
throw new Exception("Operatii.dll nu poate fi incarcat");
}
_miPatrat = t.GetMethod("Patrat");
if (_miPatrat == null)
throw new Exception("Metoda Patrat din Operatii.dll nu poate fi accesata");
_objPutere = Activator.CreateInstance(t);
}
Metoda clasei din programul executabil care realizează apelul efectiv
este:
private double MyOperatiiPutere(double x)
{
object[] args = new object[1];
args[0] = x;
return (double)_miPatrat.Invoke(_objPutere, args);
}


