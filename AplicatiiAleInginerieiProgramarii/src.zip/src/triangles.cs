private string EvaluateTriangle()
{
if (_triangle.IsInvalid())
return "0";
string s = "";
if (_triangle.IsScalene())
s += "1";
else
s += "0";
if (_triangle.IsIsosceles())
s += "1";
else
s += "0";
if (_triangle.IsEquilateral())
s += "1";
else
s += "0";
return s;
}





// [TestFixture]
public class TriangleTest
{
protected ITriangle _triangle;
[Test]
public void ValidScalene()
{
// 1. Scalen valid
_triangle.SetSides(10, 8, 5);
Assert.AreEqual("100", EvaluateTriangle(), "10-8-5");
}
// ... celelalte teste
}






[TestFixture]
public class Triangle1Test : TriangleTest
{
[SetUp]
public void Init()
{
_triangle = new Triangle1();
}
}
















namespace TestTriangles
{
public interface ITriangle
{
bool IsInvalid();
bool IsScalene();
bool IsIsosceles();
bool IsEquilateral();
void SetSides(int a, int b, int c);
}
}

















namespace TestTriangles
{
public class Triangle1 : ITriangle
{
int _a;
int _b;
int _c;
bool _flag;
public void SetSides(int a, int b, int c)
{
_a = a;
_b = b;
_c = c;
int semiperim = (a + b + c) / 2;
_flag = a == 0 || b == 0 || c == 0 || a < 0 || b < 0 || c < 0 || semiperim <= a ||
semiperim <= b || semiperim <= c;
}
public bool IsInvalid()
{
return _flag;
}
public bool IsScalene()
{
return _a != _b && _a != _c && _b != _c;
}
public bool IsIsosceles()
{
return _a == _b || _a == _c || _b == _c;
}
public bool IsEquilateral()
{
return _a == _b && _b == _c && !IsIsosceles();
}
}
}
namespace TestTriangles
{
public class Triangle2 : ITriangle
{
int _a;



int _b;
int _c;
bool _flag;
public void SetSides(int a, int b, int c)
{
_a = a;
_b = b;
_c = c;
int semiperim = (a + b + c) / 2;
_flag = a == 0 || b == 0 || c == 0;
}
public bool IsInvalid()
{
return _flag;
}
public bool IsScalene()
{
return _a != _b && _a != _c && _b != _c;
}
public bool IsIsosceles()
{
return _a == _b || _a == _c || _b == _c;
}
public bool IsEquilateral()
{
return _a == _b && _b == _c;
}
}
}
namespace TestTriangles
{
public class Triangle3 : ITriangle
{
int _a;
int _b;
int _c;
bool _flag;





















public void SetSides(int a, int b, int c)
{
_a = a;
_b = b;
_c = c;
int semiperim = (a + b + c) / 2;
_flag = a < 0 || b < 0 || c < 0;
}
public bool IsInvalid()
{
return _flag;
}
public bool IsScalene()
{
return _a != _b && _a != _c && _b != _c;
}
public bool IsIsosceles()
{
return _a == _b || _a == _c || _b == _c;
}
public bool IsEquilateral()
{
return _a == _b && _b == _c;
}
}
}
namespace TestTriangles
{
public class Triangle4 : ITriangle
{
int _a;
int _b;
int _c;
bool _flag;
public void SetSides(int a, int b, int c)
{
_a = a;
_b = b;
_c = c;
int semiperim = (a + b + c) / 2;






















_flag = a == 0 || b == 0 || c == 0 || a < 0 || b < 0 || c < 0;
}
public bool IsInvalid()
{
return _flag;
}
public bool IsScalene()
{
return _a != _b && _a != _c && _b != _c;
}
public bool IsIsosceles()
{
return _a == _b || _a == _c || _b == _c;
}
public bool IsEquilateral()
{
return _a == _b && _b == _c;
}
}
}




















