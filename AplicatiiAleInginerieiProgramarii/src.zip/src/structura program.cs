using System;
namespace MyNamespace
{
class MyClass
{
}
struct MyStruct
{
}
enum MyEnum
{
}
class MyMainClass
{
static void Main(string[] args)
{
// începutul programului propriu-zis
}
}
}