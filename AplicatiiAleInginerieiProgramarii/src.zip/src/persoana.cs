public class Person
{
// Câmp / Field
public string name;
// !!! câmp public, nerecomandat
// Constructor
public Person()
{
name = "nedefinit";
}
// Metodă / Method
public void ChangeName(string newName)
{
name = newName;
}
}
class TestPerson
{
static void Main()
{
Person person1 = new Person();
Console.WriteLine(person1.name);
person1.ChangeName("Ion Popescu");
Console.WriteLine(person1.name);
}
}