int[] nrzile = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
if (_an % 4 == 0 && _an % 100 != 0 || _an % 400 == 0)
nrzile[1] = 29;


public static int CalculeazaDiferenta(int zi, int luna, int an)