public class Car
{
public const int NumberOfWheels = 4;
public static void Drive() { }
// alte câmpuri şi metode nestatice
}
// utilizare din exteriorul clasei
Car.Drive();
int i = Car.NumberOfWheels;