Model.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
namespace TransportInfo
{
public class Model : IModel
{
#region Fields
private const string CityFileName = "cities.txt";
private List<City> _cityList;
private bool _wasModified; // lista cu oraşe va fi salvată în final doar dacă s-a modificat
#endregion



#region Properties
public int CityCount
{
get { return _cityList.Count; }
}
#endregion
#region Constructor
public Model()
{
_cityList = new List<City>();
_wasModified = false;
}
#endregion
#region Public Methods
public int GetNumberOfCities()
{
return _cityList.Count;
}
public bool DataExists()
{
if (!File.Exists(CityFileName))
{
_wasModified = true;
return false;
}
else
return true;
}
public void InitializeData()
{
StreamReader sr = new StreamReader(CityFileName);
string line;
while ((line = sr.ReadLine()) != null)
_cityList.Add(ParseCityLine(line));
sr.Close();
}





public bool Add(City city)
{
// dacă un oraş cu acelaşi nume există deja, el va fi şters
bool overwrite = false;
for (int i = 0; i < _cityList.Count; i++)
{
if (_cityList[i].Name.Trim().ToUpper() == city.Name.Trim().ToUpper())
{
_cityList.RemoveAt(i--);
overwrite = true;
}
}
// adăugarea noului oraş
_cityList.Add(city);
_wasModified = true;
return !overwrite;
}
public bool Delete(string cityName)
{
for (int i = 0; i < _cityList.Count; i++)
{
if (_cityList[i].Name == cityName)
{
_cityList.RemoveAt(i);
_wasModified = true;
return true;
}
}
return false;
}
public bool Exists(string cityName)
{
// dacă un oraş există
for (int i = 0; i < _cityList.Count; i++)
{
if (_cityList[i].Name == cityName)
return true;
}
return false;
}





public City Search(string cityName)
{
// caută un oraş după nume şi returnează obiectul corespunzător
for (int i = 0; i < _cityList.Count; i++)
{
if (_cityList[i].Name == cityName)
return _cityList[i];
}
return new City();
}
public string ListAll()
{
// creează un string cu numele tuturor oraşelor
if (_cityList.Count == 0)
return string.Empty;
StringBuilder sb = new StringBuilder();
sb.Append(_cityList[0].Name);
for (int i = 1; i < _cityList.Count; i++)
{
sb.Append(", ");
sb.Append(_cityList[i].Name);
}
return sb.ToString();
}
/// <summary>
/// Salvează datele doar dacă lista de oraşe s-a modificat
/// </summary>
/// <returns>Returnează true dacă noile date au fost salvate </returns>
public bool SaveData()
{
// dacă datele s-au modificat, ele sunt salvate
if (_wasModified)
{
StreamWriter sw = new StreamWriter(CityFileName);
for (int i = 0; i < _cityList.Count; i++)
{
City c = _cityList[i];
sw.WriteLine(c.Name + "\t" + c.Latitude + "\t" + c.Longitude);
}





sw.Close();
return true;
}
else
return false;
}
#endregion
#region Private Methods
private static City ParseCityLine(string line)
{
// citeşte informaţiile unui oraş de pe o linie din fişier
string[] toks = line.Split('\t');
City city = new City(toks[0], Convert.ToDouble(toks[1]), Convert.ToDouble(toks[2]));
return city;
}
#endregion
}
}



cities.txt
Iasi
47.167
27.583
Bacau
46.567
26.917
Piatra Neamt 46.933
26.383
Suceava
47.667
26.183
Botosani
47.733
26.667
Vaslui
46.633
27.733
Bucuresti
44.44
26.1
Cluj-Napoca
46.78
23.59
Timisoara
45.76
21.23
Constanta
44.18
28.63
Brasov
45.66
25.61
Chisinau
47.033
28.833
Balti
47.75
27.917
Amsterdam
52.383
4.9
Atena
37.967
23.767
Belgrad
44.817
20.45
Berlin
52.533
13.4
Bruxelles
50.85
4.35
Budapesta
47.483
19.083
Londra
51.517
-0.1
Madrid
40.417
-3.75
Moscova
55.75
37.583
Oslo
59.917
10.75
Praga
50.083
14.367
Paris
48.833
2.333
Roma
41.9
12.5
Sofia
42.75
23.333
Viena
48.2
16.367






City.cs
namespace TransportInfo
{
public struct City
{
// readonly pentru ca structura să fie immutable
// alternativa este abordarea cu câmpuri private şi proprietăţi publice
public readonly double Latitude, Longitude;
public readonly string Name;
public City(string name, double latitude, double longitude)
{
Name = name;
Latitude = latitude;
Longitude = longitude;
}
}
}
Calculator.cs
namespace TransportInfo
{
public class BusinessCalculator
{
#region Public Static Methods
public static double Distance(City c1, City c2)
{
// calculează distanţa în kilometri între două puncte de pe suprafaţa Pământului
// identificate prin latitudine şi longitudine utilizând coordonate sferice
double a1 = c1.Latitude * Math.PI / 180.0;



double b1 = c1.Longitude * Math.PI / 180.0;
double a2 = c2.Latitude * Math.PI / 180.0;
double b2 = c2.Longitude * Math.PI / 180.0;
const double EarthRadius = 6378; // raza Pământului în km
return (int)(EarthRadius * Math.Acos(Math.Cos(a1) * Math.Cos(b1) * Math.Cos(a2)
* Math.Cos(b2) + Math.Cos(a1) * Math.Sin(b1) * Math.Cos(a2) * Math.Sin(b2) +
Math.Sin(a1) * Math.Sin(a2)));
}
public static double Cost(double distance)
{
// aici se poate introduce orice funcţie de calcul al costului
double euro = 5 + distance / 30.0;
return euro * 4.3;
}
#endregion
}
}






public enum UserChoice { AdminMenu, UserMenu, PreviousMenu, Route, AddCity,
RemoveCity, Exit, List, Undefined };
public enum MenuState { Main, Administrator, User };







static class Program
{
static void Main()
{
Model model = new Model();
ConsoleView view = new ConsoleView(model);
Presenter presenter = new Presenter(view, model);
view.SetPresenter(presenter);
view.Start();
}
}







static class Program
{
[STAThread]
static void Main()
{
Application.EnableVisualStyles();
Application.SetCompatibleTextRenderingDefault(false);
Model model = new Model();
FormView view = new FormView();
Presenter presenter = new Presenter(view, model);
view.SetModel(model);
view.SetPresenter(presenter);
Application.Run(view);
}
}







#region Disable Close X Button
const int MF_BYPOSITION = 0x400;
[DllImport("User32")]
private static extern int RemoveMenu(IntPtr hMenu, int nPosition, int wFlags);
[DllImport("User32")]
private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);
[DllImport("User32")]
private static extern int GetMenuItemCount(IntPtr hWnd);
private void FormView_Load(object sender, EventArgs e)
{
IntPtr hMenu = GetSystemMenu(this.Handle, false);
int menuItemCount = GetMenuItemCount(hMenu);
RemoveMenu(hMenu, menuItemCount - 1, MF_BYPOSITION);
}
#endregion





