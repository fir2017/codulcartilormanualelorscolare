bool error = DoSomething();
if (error)
Console.WriteLine("Eroare");
Environment.Exit(1);








int KernighanRitchie() {
int a = 0, b = 0;
while (a != 10) {
a++;
b--;
}
return b;
}












int Extended()
{
int a = 0, b = 0;
while (a != 10)
{
a++;
b--;
}
return b;
}

















using System . Windows . Forms;
namespace LabIP {
public class HelloWorld:System . Windows . Forms . Form {
public HelloWorld ( ) {
InitializeComponent ( );
}
protected override void Dispose ( bool disposing ) {
if( disposing ) {
if( components != null ) {
components . Dispose ( );
}
}
base . Dispose ( disposing );
}
static void Main ( ) {
Application . Run ( new HelloWorld ( ) );
}
private void button1_Click ( object sender , System . EventArgs e ) {
string STRING = "Hello World!";
display ( STRING );
}
private void display ( string STR ) {
MessageBox . Show ( STR , ":-)" );
}
}
}


















#region Fields
private DateOfBirth _dob;
private Address _address;
#endregion





















class badly_named : MyBaseClass
{
public void doTheFirstThing();
public void DoThe2ndThing();
public void do_the_third_thing();
}






















private int description; // ortografie corectă
public Constructor(int descripton) // ortografie incorectă pentru "description"
{
this.description = description; // ortografie corectă în ambele părţi, câmpul rămâne 0
}

























int err = OpenFile(s);

FuncţieApelată
{
...
if (condiţii)
throw ...
...
}
FuncţieApelantă
{
...
try
{
FuncţieApelată();
}
catch (Exception e) // catch fără parametru dacă nu interesează detaliile excepţiei
{
// cod pentru tratarea excepţiei, care prelucrează parametrul e
}
...
}






try
{
FunctieApelata();
}
catch (Exception ex)
{
...
}


















private void FunctieApelata(int a)
{
if (a == 0)
throw new Exception("Argument zero");
}
private void FunctieApelanta()
{
FunctieApelata(0);
}



















private void FunctieApelanta()
{
try
{
FunctieApelata(0);
}
catch (Exception ex)
{
// ex.Message este "Argument zero"
}
}




















public class MyException: Exception
{
public int _info; // informaţie suplimentară
// în constructor se apelează şi constructorul clasei de bază
public MyException(int val) : base()
{
_info = val;
}
}






















throw new MyException(3);
























try
{
FunctieApelata(x);
}
catch (MyException myex)
{
...
}
catch (Exception ex)
{
...
}





















static class Program
{
static void Main()
{
// Adăugarea unui event handler pentru prinderea excepţiilor
// din firul principal al interfeţei cu utilizatorul
Application.ThreadException +=
new ThreadExceptionEventHandler(OnThreadException);
// Adăugarea unui event handler pentru toate firele de execuţie din appdomain
// cu excepţia firului principal al interfeţei cu utilizatorul
AppDomain.CurrentDomain.UnhandledException +=
new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
Application.EnableVisualStyles();
Application.SetCompatibleTextRenderingDefault(false);
Application.Run(new MyForm()); // MyForm este fereastra principală a programului
}
// Tratează excepţiile din firul principal al interfeţei cu utilizatorul
static void OnThreadException(object sender, ThreadExceptionEventArgs t)
{
// Afişează detaliile excepţiei
MessageBox.Show(t.Exception.ToString(), "OnThreadException");
}
// Tratează excepţiile din toate celelalte fire de execuţie
static void CurrentDomain_UnhandledException(object sender,
UnhandledExceptionEventArgs e)
{
// Afişează detaliile excepţiei
MessageBox.Show(e.ExceptionObject.ToString(), "CurrentDomain_UnhandledException");
}
}
























Application.Run(new MainForm());















string str1 = "Microsoft ";
string str2 = "Word";
str1 = str1 + str2; // sau str1 += str2; => str1 == "Microsoft Word"






















double d = 0.5;
string str = string.Format("Patratul numarului {0} este {1}", d, d * d);
Acelaşi rezultat s-ar fi putut obţine astfel:
str = "Patratul numarului " + d.ToString() + " este " + (d * d).ToString();



















string str=string.Format("Patratul numarului {0:F2} este {1:F2}", d, d*d);
MessageBox.Show(str);



















string listaNumere = "";
for (int i=0; i<1000; i++)
listaNumere = listaNumere + " " + (i + 1).ToString();





















StringBuilder sbListaNumere = new StringBuilder(10000);
for (int i = 0; i < 1000; i++)
{
sbListaNumere.Append(" ");
sbListaNumere.Append((i+1).ToString());
}
string listaNumere2 = sbListaNumere.ToString();

























using System.Text;





















System.Text.StringBuilder sbListaNumere = new System.Text.StringBuilder(10000);





















public partial class Student
{
public void Learn()
{
}
}
public partial class Student
{
public void TakeExam()
{
}
}
























class Person
{
private string _name; // câmp
public string Name
// proprietate
{
get
{
return _name;
}
}
}
Person p1 = new Person();
Console.Write(p1.Name); // se apelează accesorul get





















private int _number;
public int Number
{
get
{
return _number++; // !!! nerecomandat
}
}
























class Student
{
private string _name;
public string Name
{
get
{
return _name != null ? _name : "NA";
}
}
}























class Person
{
private string _name;
public string Name
{
get
{
return _name;
}
set
{
_name = value;
}
}
}

Person p1 = new Person();
p1.Name = "Joe"; // se apelează accesorul set cu value = "Joe"















class TimePeriod
{
private double _seconds;
public double Hours
{
get { return _seconds / 3600; }
set { _seconds = value * 3600; }
}
}

class Program
{
static void Main()
{
TimePeriod t = new TimePeriod();
// atribuirea proprietăţii Hours determină apelul accesorului set
t.Hours = 24;
// evaluarea proprietăţii Hours determină apelul accesorului get
Console.WriteLine("Timpul in ore: " + t.Hours);
}
}


















public string Name
{
get
{
return _name;
}
protected set
{
_name = value;
}
}

























public class Date
{
private int _month = 7;
public int Month
{
get
{
return _month;
}
set
{
if ((value > 0) && (value < 13))
{
_month = value;
}
}
}
}












































































