Subsistemele
class SubsystemOne
{
public void MethodOne()
{
Console.WriteLine("Metoda subsistemului 1 ");
}
}
class SubsystemTwo
{
public void MethodTwo()
{
Console.WriteLine("Metoda subsistemului 2");
}
}
class SubsystemThree
{
public void MethodThree()
{
Console.WriteLine("Metoda subsistemului 3");
}
}
class SubsystemFour
{
public void MethodFour()
{
Console.WriteLine("Metoda subsistemului 4");
}
}


Faţada
class Facade
{
SubSystemOne _one;
SubSystemTwo _two;
SubSystemThree _three;
SubSystemFour _four;
public Facade()
{
_one = new SubSystemOne();
_two = new SubSystemTwo();
_three = new SubSystemThree();
_four = new SubSystemFour();
}
public void MethodA()
{
Console.WriteLine("Metoda A a Fatadei");
_one.MethodOne();
_two.MethodTwo();
_four.MethodFour();
}
public void MethodB()
{
Console.WriteLine("Metoda B a Fatadei");
_two.MethodTwo();
_three.MethodThree();
}
}
Clientul
public class Client
{
public static void Main(string[] args)
{
Facade f = new Facade();
f.MethodA();
f.MethodB();
Console.ReadLine();
}
}





public MainForm()
{
InitializeComponent();
string[] produse = Facade.Produse();
for (int i = 0; i < produse.Length; i++)
checkedListBoxProduse.Items.Add(produse[i], false);
}







private bool CNPValid()
{
string cnp = textBoxCNP.Text;
if (cnp.Length != 13)
return false;
int suma = Convert.ToInt32(cnp[0].ToString()) * 2 +
Convert.ToInt32(cnp[1].ToString()) * 7 +
Convert.ToInt32(cnp[2].ToString()) * 9 +
Convert.ToInt32(cnp[3].ToString()) * 1 +
Convert.ToInt32(cnp[4].ToString()) * 4 +
Convert.ToInt32(cnp[5].ToString()) * 6 +
Convert.ToInt32(cnp[6].ToString()) * 3 +
Convert.ToInt32(cnp[7].ToString()) * 5 +
Convert.ToInt32(cnp[8].ToString()) * 8 +
Convert.ToInt32(cnp[9].ToString()) * 2 +
Convert.ToInt32(cnp[10].ToString()) * 7 +
Convert.ToInt32(cnp[11].ToString()) * 9;
int rest = suma % 11;
if ((rest < 10) && (rest.ToString() == cnp[12].ToString()) ||
(rest == 10) && (cnp[12] == '1'))
return true;
return false;
}


