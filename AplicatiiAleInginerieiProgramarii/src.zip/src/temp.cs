public static class TemperatureConverter
{
public static double CelsiusToFahrenheit(string temperatureCelsius)
{
// conversia argumentului din string în double
double celsius = Convert.ToDouble(temperatureCelsius);
// conversia din grade Celsius în grade Fahrenheit
double fahrenheit = (celsius * 9 / 5) + 32;
return fahrenheit;
}
public static double FahrenheitToCelsius(string temperatureFahrenheit)
{
double fahrenheit = Convert.ToDouble(temperatureFahrenheit);
double celsius = (fahrenheit – 32) * 5 / 9;
return celsius;
}
}
class TestTemperatureConverter
{
static void Main()
{
Console.WriteLine("Selectati directia de conversie");
Console.WriteLine("1. Din grade Celsius in grade Fahrenheit");
Console.WriteLine("2. Din grade Fahrenheit in grade Celsius");
Console.Write(":");
string selection = Console.ReadLine();
double f, c = 0;
switch (selection)
{
case "1":
Console.Write("Introduceti temperatura in grade Celsius: ");
f = TemperatureConverter.CelsiusToFahrenheit(Console.ReadLine());
// se afişează rezultatul cu 2 zecimale
Console.WriteLine("Temperatura in grade Fahrenheit: {0:F2}", f);
break;
case "2":
Console.Write("Introduceti temperatura in grade Fahrenheit: ");
c = TemperatureConverter.FahrenheitToCelsius(Console.ReadLine());
Console.WriteLine("Temperatura in grade Celsius: {0:F2}", c);
break;
default:
Console.WriteLine("Selectati un tip de conversie");
break;
}
// aşteaptă apăsarea tastei ENTER
Console.ReadLine();
}
}