Clasele Produs
abstract class Product
{
}
class ConcreteProductA : Product
{
}
class ConcreteProductB : Product
{
}



Clasele Creator
abstract class Creator
{
// Metode
abstract public Product FactoryMethod();
}
class ConcreteCreatorA : Creator
{
// Metode
override public Product FactoryMethod()
{
return new ConcreteProductA();
}
}
class ConcreteCreatorB : Creator
{
// Metode
override public Product FactoryMethod()
{
return new ConcreteProductB();
}
}
Clientul
class Client
{
public static void Main( string[] args )
{
// FactoryMethod returnează ProductA
Creator c = new ConcreteCreatorA();
Product p = c.FactoryMethod();
Console.WriteLine("A fost creat {0}", p );
// FactoryMethod returnează ProductB
c = new ConcreteCreatorB();
p = c.FactoryMethod();
Console.WriteLine("A fost creat {0}", p );
}
}



