public class MathOps
{
public static double Add(double x, double y)
{
return x + y;
}
public static double Sub(double x, double y)
{
return x - y - 1; // rezultat incorect
}
public static double Mul(double x, double y)
{
return x * y + 0.5; // rezultat incorect
}
public static double Div(double x, double y)
{
if (x == 0 && y == 0)
throw new Exception("Undefined operation.");
// if (y == 0)
// throw new Exception("Division by zero."); // lipseşte excepţia
return x / y;
}public static double Pow(double x, double y)
{
throw new Exception("The method or operation is not implemented.");
}
}


[TestFixture]
public class OperatiiTest
{
...
}





[Test]
public void Addition()
{
Assert.AreEqual(3, MathOps.Add(1, 2));
}








[Test]
public void Subtraction()
{
Assert.AreEqual(-1, MathOps.Sub(1, 2));
}
[Test]
public void Multiplication()
{
Assert.AreEqual(12, MathOps.Mul(3, 4));
}
[Test]
public void Division()
{
Assert.AreEqual(2.0 / 3.0, MathOps.Div(2, 3));
}









[Test]
[ExpectedException(typeof(Exception))]
public void DivisionExc1()
{
MathOps.Div(0, 0);
}
[Test]
[ExpectedException(typeof(Exception))]
public void DivisionExc2()
{
MathOps.Div(5, 0);
}








[Test]
[Ignore("Operatia nu este inca implementata")]
public void Power()
{
Assert.AreEqual(8, MathOps.Pow(2, 3));
}








[TestFixture]
public class AccountTest
{
Account _source;
Account _destination;
[SetUp]
public void Init()
{
_source = new Account();
_source.Deposit(200.00f);
_destination = new Account();
_destination.Deposit(150.00f);
}
[Test]
public void TransferFunds()
{
_source.TransferFunds(_destination, 100.00f);
Assert.AreEqual(250.00f, _destination.Balance);
Assert.AreEqual(100.00f, _source.Balance);
}
}







