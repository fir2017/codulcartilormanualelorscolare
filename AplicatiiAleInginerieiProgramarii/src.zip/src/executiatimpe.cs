

long startTicks = DateTime.Now.Ticks;
ApelFunctie();
double dif = (DateTime.Now.Ticks - startTicks) / 10000.0;
// dif este calculată în milisecunde




int NumarDivizori (int *n);
Importarea acestei funcţii se va face astfel:
[DllImport("Divizibilitate", EntryPoint="NumarDivizori")]
private static unsafe extern int DllNumarDivizori(int* n);
public static unsafe int NumarDivizori(int n)
{
int arg = n, rez = 0;
// adresa argumentului este "fixată" în memorie, deoarece managementul automat
// al memoriei presupune "mutarea" diferitelor zone de memorie în vederea optimizării
fixed (int *pArg = &arg)
{
// apelul se face cu adresa argumentului arg
rez = DllNumarDivizori(pArg);
}
return rez;
}







extern "C" __declspec(dllexport) char* MyAppend(char* first, char* second)
{
char *result = new char[strlen(first) + strlen(second)];
strcpy(result, first);
strcat(result, second);
return result;
}
Importarea acestei funcţii se va face în felul următor:
[DllImport("StringDll", EntryPoint = "MyAppend")]
public static extern unsafe IntPtr StringAppend(
[MarshalAs(UnmanagedType.LPStr)]
string arg1,
[MarshalAs(UnmanagedType.LPStr)]
string arg2
);







IntPtr target = StringAppend(str1, str2);
string s = Marshal.PtrToStringAnsi(target);








[DllImport("kernel32", EntryPoint = "QueryPerformanceFrequency")]
private static unsafe extern bool QueryPerformanceFrequency(Int64* f);
[DllImport("kernel32", EntryPoint = "QueryPerformanceCounter")]
private static unsafe extern bool QueryPerformanceCounter(Int64* c);
static Int64 _t1, _t2, _htrFrecv;
static bool _htrInit;
static PerformanceCounterSpeed()
{
// iniţializarea numărătorului - o singură dată înainte de utilizarea clasei
InitCounter();
}
private static unsafe bool InitCounter()
{
_t1 = 0; _t2 = 0; _htrFrecv = 0; _htrInit = false;
fixed (Int64* frecv = &_htrFrecv)
{
_htrInit = QueryPerformanceFrequency(frecv);
}
return _htrInit;
}







public unsafe void BeginTest()
{
fixed (Int64* t1 = &_t1)
{
QueryPerformanceCounter(t1);
}
}
/// <summary>
/// Returnează diferenţa în milisecunde
/// </summary>
/// <returns></returns>
public unsafe double EndTest()
{
fixed (Int64* t2 = &_t2)
{
QueryPerformanceCounter(t2);
}
Int64 difCounts = _t2 - _t1;
double difSeconds = (double)difCounts / (double)_htrFrecv;
return difSeconds * 1000.0;
}





[System.Security.SuppressUnmanagedCodeSecurity()]
private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);













long startTicks = Stopwatch.GetTimestamp();
ApelFunctie();
double dif = (Stopwatch.GetTimestamp() - _startTicks) * 1000.0 / Stopwatch.Frequency;
// dif este calculată în milisecunde
















C:\WINDOWS\Microsoft.NET\Framework\v2.0.50727\ngen.exe install nume-assembly















void BeginTest();
double EndTest(); // returnează diferenţa



















namespace Speed
{
public class Sorting
{
public static void QuickSort(double[] vector)
{
DoQuickSort(vector, 0, vector.Length - 1);
}
private static void DoQuickSort(double[] vector, int low, int high)
{
if (high > low)
{
int k = Partition(vector, low, high); // procedura de partiţionare
DoQuickSort(vector, low, k - 1);
DoQuickSort(vector, k + 1, high);
}
}
private static int Partition(double[] vector, int low, int high)
{
int l = low;
int h = high;
double x = vector[l];
double temp;
while (l < h)
{
while ((vector[l] <= x) && (l < high)) l++;
while ((vector[h] > x) && (h >= low)) h--;
if (l < h)
{
temp = vector[l];
vector[l] = vector[h];
vector[h] = temp;
}
}
temp = vector[h];
vector[h] = vector[low];
vector[low] = temp;
return h;
}
public static void ShellSort(double[] vector)
{
for (int dist = vector.Length / 2; dist > 0; dist /= 2)
for (int i = dist; i < vector.Length; i++)
for (int j = i - dist; j >= 0 && vector[j] > vector[j + dist]; j -= dist)
{
double aux = vector[j];
vector[j] = vector[j + dist];
vector[j + dist] = aux;
}
}


public static void BubbleSort(double[] vector)
{
// de completat cu varianta neoptimizată O(n2)
}
}
}


