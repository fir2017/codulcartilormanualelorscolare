System.Windows.Forms.PaintEventArgs e



e.Graphics.DrawLine(Pen pen, int x1, int y1, int x2, int y2)

e.Graphics.DrawLine(Pens.Black, 10, 10, 20, 40);
e.Graphics.DrawRectangle(Pen pen, int x, int y, int latime, int inaltime)
e.Graphics.FillRectangle(Brush b, int x, int y, int latime, int inaltime)

Brush b = new SolidBrush(Color.Blue);

e.Graphics.FillRectangle(Brushes.White, 0, 0, 10, 20);
e.Graphics.DrawRectangle(Pens.Black, 0, 0, 10, 20);

DrawString (string s, Font font, Brush brush, int x, int y)


Font font = new Font("Arial", 10);


SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer |
ControlStyles.UserPaint, true);


