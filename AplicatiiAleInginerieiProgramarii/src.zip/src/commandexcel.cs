Comanda abstractă
abstract class Command
{
protected Receiver _receiver;
public Command(Receiver receiver)
{
_receiver = receiver;
}





abstract public void Execute();
}
Comanda concretă
class ConcreteCommand : Command
{
public ConcreteCommand(Receiver receiver) : base(receiver)
{
}
public override void Execute()
{
_receiver.Action();
}
}
Destinatarul
class Receiver
{
public void Action()
{
Console.WriteLine("Apelul metodei din destinatar");
}
}
Invocatorul
class Invoker
{
private Command _command;
public void SetCommand(Command command)
{
_command = command;
}
public void ExecuteCommand()
{
_command.Execute();
}
}






Clientul
public class Client
{
public static void Main(string[] args)
{
// Se creează destinatarul, comanda şi invocatorul
Receiver r = new Receiver();
Command c = new ConcreteCommand(r);
Invoker i = new Invoker();
// Se setează şi se execută comanda
i.SetCommand(c);
i.ExecuteCommand();
}
}







MainForm.cs
namespace Spreadsheet
{
public partial class MainForm : Form
{
public MainForm()
{
InitializeComponent();





_grid = new TextBoxGrid(Controls, 25, 120,
new KeyEventHandler(textBox_KeyDown),
new EventHandler(textBox_Leave));
_invoker = new Invoker(_grid);
}
TextBoxGrid _grid;
Invoker _invoker;
int _selected;
private void textBox_KeyDown(object sender, KeyEventArgs e)
{
if (e.KeyCode == Keys.Enter)
{
// când se apasă ENTER într-o celulă
ExtendedTextBox tb = (ExtendedTextBox)sender;
string name = tb.Name;
_selected = Convert.ToInt32(name.Substring(2));
this.ActiveControl = _grid.GetSuccessor(_selected);
}
}
private void textBox_Leave(object sender, EventArgs e)
{
// când o celulă nu mai este controlul selectat activ din fereastră
Control ac = this.ActiveControl;
ExtendedTextBox tb = (ExtendedTextBox)sender;
string name = tb.Name;
_selected = Convert.ToInt32(name.Substring(2));
tb.FormatText();
// de completat - tratarea schimbării textului
this.ActiveControl = ac;
UpdateUndoRedoCombos();
}
private void buttonColor_Click(object sender, EventArgs e)
{
if (colorDialog1.ShowDialog() != DialogResult.OK)
return;






Color c = colorDialog1.Color;
buttonColor.ForeColor = c;
//buttonColor.BackColor = Color.FromArgb(255 - c.R, 255 - c.G, 255 - c.B);
// de completat
UpdateUndoRedoCombos();
}
private void buttonNormal_Click(object sender, EventArgs e)
{
// de completat
UpdateUndoRedoCombos();
}
private void buttonBold_Click(object sender, EventArgs e)
{
// de completat
UpdateUndoRedoCombos();
}
private void buttonItalic_Click(object sender, EventArgs e)
{
// de completat
UpdateUndoRedoCombos();
}
private void UpdateUndoRedoCombos()
{
comboBoxUndo.Items.Clear();
string[] str = _invoker.UndoNames.ToArray();
for (int i = 0; i < str.Length; i++)
comboBoxUndo.Items.Add(str[i]);
if (comboBoxUndo.Items.Count > 0)
{
comboBoxUndo.SelectedIndex = 0;
buttonUndo.Enabled = true;
}
else
buttonUndo.Enabled = false;
comboBoxRedo.Items.Clear();
str = _invoker.RedoNames.ToArray();
for (int i = 0; i < str.Length; i++)
comboBoxRedo.Items.Add(str[i]);





if (comboBoxRedo.Items.Count > 0)
{
comboBoxRedo.SelectedIndex = 0;
buttonRedo.Enabled = true;
}
else
buttonRedo.Enabled = false;
}
private void buttonUndo_Click(object sender, EventArgs e)
{
_invoker.Undo();
UpdateUndoRedoCombos();
}
private void buttonRedo_Click(object sender, EventArgs e)
{
_invoker.Redo();
UpdateUndoRedoCombos();
}
private void buttonExit_Click(object sender, EventArgs e)
{
Close();
}
}
}
ExtendedTextBox.cs
namespace Spreadsheet
{
class ExtendedTextBox : TextBox
{
private string _previousText;
public string PreviousText
{
get { return _previousText; }
set { _previousText = value; }
}






public ExtendedTextBox()
: base()
{
_previousText = "";
}
public void FormatText()
{
double d;
if (double.TryParse(Text, out d))
{
Text = d.ToString("F2");
TextAlign = HorizontalAlignment.Right;
}
else
TextAlign = HorizontalAlignment.Left;
}
}
}
TextBoxGrid.cs
namespace Spreadsheet
{
class TextBoxGrid
{
private ExtendedTextBox[] _textBoxes;
public const int Size = 5;
public TextBoxGrid(Control.ControlCollection controlCollection, int left, int top,
KeyEventHandler keyDownEvent, EventHandler leaveEvent)
{
_textBoxes = new ExtendedTextBox[Size * Size];
for (int i = 0; i < Size * Size; i++)
{
int x = i % Size;
int y = i / Size;
_textBoxes[i] = new ExtendedTextBox();
_textBoxes[i].Width = 100;
_textBoxes[i].Height = 20;
_textBoxes[i].Left = left + x * 100;
_textBoxes[i].Top = top + y * 20;
_textBoxes[i].Text = "";
_textBoxes[i].Name = "Tb" + i;




_textBoxes[i].KeyDown += keyDownEvent;
_textBoxes[i].Leave += leaveEvent;
controlCollection.Add(_textBoxes[i]);
}
for (int i = 0; i < Size * Size; i++)
_textBoxes[i].PreviousText = _textBoxes[i].Text;
Label[] labelsX = new Label[Size];
for (int i = 0; i < Size; i++)
{
labelsX[i] = new Label();
labelsX[i].Text = ((char)(i + 'A')).ToString();
labelsX[i].Left = left + i * 100 + 48;
labelsX[i].Top = top - 15;
controlCollection.Add(labelsX[i]);
}
Label[] labelsY = new Label[Size];
for (int i = 0; i < Size; i++)
{
labelsY[i] = new Label();
labelsY[i].Text = (i + 1).ToString();
labelsY[i].Left = left - 15;
labelsY[i].Height = 20;
labelsY[i].Top = top + i * 20 + 4;
controlCollection.Add(labelsY[i]);
}
}
public void Clear()
{
for (int i = 0; i < Size * Size; i++)
{
_textBoxes[i].Clear();
_textBoxes[i].Font = new Font(_textBoxes[i].Font, FontStyle.Regular);
_textBoxes[i].ForeColor = Color.Black;
_textBoxes[i].PreviousText = _textBoxes[i].Text;
}
}
public ExtendedTextBox GetSuccessor(int cellNumber)
{
cellNumber = (cellNumber + 1) % (Size*Size);
return _textBoxes[cellNumber];
}





public string GetCoords(int cellNumber)
{
char tbx = (char)((cellNumber % Size) + 'A');
int tby = cellNumber / Size + 1;
return tbx.ToString() + tby;
}
public ExtendedTextBox GetCell(int cellNumber)
{
return _textBoxes[cellNumber];
}
}
}
ICommand.cs
namespace Spreadsheet
{
interface ICommand
{
bool Execute();
void Undo();
void Redo();
}
}
Invoker.cs
namespace Spreadsheet
{
class Invoker
{
private TextBoxGrid _grid;
private Stack<ICommand> _commands;
private Stack<ICommand> _redoCommands;
private Stack<string> _undoNames, _redoNames;
public Stack<string> RedoNames
{
get { return _redoNames; }
}





public Stack<string> UndoNames
{
get { return _undoNames; }
}
public Invoker(TextBoxGrid grid)
{
_grid = grid;
_commands = new Stack<ICommand>();
_redoCommands = new Stack<ICommand>();
_undoNames = new Stack<string>();
_redoNames = new Stack<string>();
}
public void SetAndExecute(ICommand command, string description)
{
// de completat
}
public void Undo() // (int level)
{
// este foarte simplă anularea mai multor niveluri de acţiuni:
// a ultimelor "level" comenzi
// de completat
}
public void Redo() // (int level)
{
// de completat
}
}
}
ChangeColorCommand.cs
namespace Spreadsheet
{
class ChangeColorCommand : ICommand
{
ExtendedTextBox _textBox;
// alte câmpuri











public ChangeColorCommand(ExtendedTextBox textBox, Color color)
{
//...
}
public bool Execute()
{
//...
// returnează true dacă se modifică ceva în _textBox
// returnează false dacă nu se modifică nimic
return false;
}
public void Undo()
{
//...
}
public void Redo()
{
//...
}
}
}
ChangeFormatCommand.cs
namespace Spreadsheet
{
class ChangeFormatCommand : ICommand
{
ExtendedTextBox _textBox;
// alte câmpuri
public ChangeFormatCommand(ExtendedTextBox textBox, FontStyle format)
{
//...
}
public bool Execute()
{
//...
// exemplu de schimbare a corpului de literă:
// _textBox.Font = new Font(_textBox.Font, _newStyle);
// returnează true dacă se modifică ceva în _textBox




















// returnează false dacă nu se modifică nimic
return false;
}
public void Undo()
{
//...
}
public void Redo()
{
//...
}
}
}
ChangeTextCommand.cs
namespace Spreadsheet
{
class ChangeTextCommand : ICommand
{
ExtendedTextBox _textBox;
// alte câmpuri
public ChangeTextCommand(ExtendedTextBox textBox)
{
//...
}
public bool Execute()
{
// textul nou deja există în _textBox.Text
//...
// returnează true dacă se modifică ceva în _textBox
// returnează false dacă nu se modifică nimic
return false;
}
public void Undo()
{
//...
}
public void Redo()
{
//...
}
}
}















