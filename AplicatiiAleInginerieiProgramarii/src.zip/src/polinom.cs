IEquation eq = new PolyEquation(x2, x1, x0);
textBoxSolutie.Text = eq.Solve();

	eq = new TrigEquation(TrigEquation.TrigonometricFunction.Sin, arg);
textBoxSolutie.Text = eq.Solve();

if (_x2 == 0)
{
_eqType = EquationType.FirstDegree;
// soluţie: -_x0 / _x1
}
else if (delta > 0)
{
double sqrtDelta = Math.Sqrt(delta);
double sol1 = (-_x1 + sqrtDelta) / (2.0 * _x2);
double sol2 = (-_x1 - sqrtDelta) / (2.0 * _x2);
// soluţii: sol1, sol2
}
else if (delta == 0)
{
double sol = (-_x1) / (2.0 * _x2);
// soluţie: sol
}
else
{
double rsol = -_x1 / (2.0 * _x2);
double isol = Math.Sqrt(-delta) / (2.0 * _x2);
// soluţii: rsol ± isol
}