public void Locals()
{
int i;
for (i = 0; i < 3; i++)
DoSomething();
for (i = 2; i < 5; i++)
DoSomething();
}