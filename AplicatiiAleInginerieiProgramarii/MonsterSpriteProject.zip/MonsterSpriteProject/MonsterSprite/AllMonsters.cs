using System;
using System.Collections.Generic;
using System.Text;

namespace MonsterSpriteProject.MonsterSprite
{
	public class AllMonsters
	{
		List <Monster> Monsters;
	}
}
