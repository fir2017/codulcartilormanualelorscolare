using System;
using System.Collections.Generic;
using System.Text;

namespace MonsterSpriteProject.MonsterSprite
{
	public class Clonare
	{
		public static object Clone(object obj)
		{
			throw new NotImplementedException();
		}
	}
}
