using System;
using System.Collections.Generic;
using System.Text;

namespace MonsterSpriteProject.MonsterSprite
{
	public class MainForm
	{
		List <Monster> _listMonsters;
		MonsterSprite _mainMonster;
		Random _rand = new Random();
		int _monsterType = 0;
		int _x;
		int _y;
		long _elapsed;
		const int MonsterSize = 200;
		const int MaxLevels = 4;
		bool _gameOver = false;

		public MainForm()
		{
			throw new NotImplementedException();
		}

		public void loadSettingsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			throw new NotImplementedException();
		}

		private void startNewGameToolStripMenuItem_Click(object sender, EventArgs e)
		{
			throw new NotImplementedException();
		}

		private void Redraw()
		{
			throw new NotImplementedException();
		}

		private void exitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			throw new NotImplementedException();
		}

		private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
		{
			throw new NotImplementedException();
		}

		private void pictureBox_Paint(object sender, PaintEventArgs e)
		{
			throw new NotImplementedException();
		}

		private void ShootMonster()
		{
			throw new NotImplementedException();
		}

		private void pictureBox_MouseDown(object sender, MouseEventArgs e)
		{
			throw new NotImplementedException();
		}

		private void timer_Tick(object sender, EventArgs e)
		{
			throw new NotImplementedException();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			throw new NotImplementedException();
		}
	}
}
