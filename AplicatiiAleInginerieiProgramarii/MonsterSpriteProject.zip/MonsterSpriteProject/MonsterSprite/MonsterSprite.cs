using System;
using System.Collections.Generic;
using System.Text;

namespace MonsterSpriteProject.MonsterSprite
{
	public class MonsterSprite
	{
		protected Bitmap _imagine;
		protected Colors _color;
		protected int _lives;
		protected int _maxLives;
		protected string _ai;

		public MonsterSprite(Monster settings)
		{
			throw new NotImplementedException();
		}

		public Color GetColor(string colorName)
		{
			throw new NotImplementedException();
		}

		public void InitAll()
		{
			throw new NotImplementedException();
		}

		public void Draw(Graphics g, int x, int y)
		{
			throw new NotImplementedException();
		}

		public bool Shoot()
		{
			throw new NotImplementedException();
		}
	}
}
