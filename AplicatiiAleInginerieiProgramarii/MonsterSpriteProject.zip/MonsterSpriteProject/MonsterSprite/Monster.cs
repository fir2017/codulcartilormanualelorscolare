using System;
using System.Collections.Generic;
using System.Text;

namespace MonsterSpriteProject.MonsterSprite
{
	public class Monster
	{
		string Image;
		string Color;
		string Lives;
	}
}
