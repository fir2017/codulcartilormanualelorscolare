using System;
using System.Collections.Generic;
using System.Text;

namespace UIproject.UI
{
	public class MainForm
	{
		OpenFileDialog opneFileDialog;
		TabControl tabControl;

		public void menuItemOpen_Click(object sender, EventArgs e)
		{
			throw new NotImplementedException();
		}

		public void menuItemAbout_Click(object sender, EventArgs e)
		{
			throw new NotImplementedException();
		}

		public void menuItemExit_Click(object sender, EventArgs e)
		{
			throw new NotImplementedException();
		}
	}
}
