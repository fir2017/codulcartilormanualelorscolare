using System;
using System.Collections.Generic;
using System.Text;

namespace UIproject.UI
{
	public class TextPage : Page
	{
		public TextPage(string fileName)
		{
			throw new NotImplementedException();
		}
	}
}
