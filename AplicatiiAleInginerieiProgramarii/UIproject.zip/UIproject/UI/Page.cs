using System;
using System.Collections.Generic;
using System.Text;

namespace UIproject.UI
{
	public class Page
	{
		protected string _name;
		protected Control _content;

		public string Name
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public Control Content
		{
			get
			{
				throw new NotImplementedException();
			}
		}
	}
}
