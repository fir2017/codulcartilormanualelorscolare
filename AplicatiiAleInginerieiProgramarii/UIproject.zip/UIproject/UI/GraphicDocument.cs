using System;
using System.Collections.Generic;
using System.Text;

namespace UIproject.UI
{
	public class GraphicDocument : Document
	{
		public GraphicDocument(string fileName)
		{
			throw new NotImplementedException();
		}

		public override Page CreatePage(string fileName)
		{
			throw new NotImplementedException();
		}
	}
}
