using System;
using System.Collections.Generic;
using System.Text;

namespace UIproject.UI
{
	public class Document
	{
		protected List < Page> _pages;

		public List < Page> Pages
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		protected Document(string indexFileName)
		{
			throw new NotImplementedException();
		}

		protected Page CreatePage(string fileName)
		{
			throw new NotImplementedException();
		}
	}
}
