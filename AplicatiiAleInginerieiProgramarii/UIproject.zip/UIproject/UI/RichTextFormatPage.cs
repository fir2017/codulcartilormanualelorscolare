using System;
using System.Collections.Generic;
using System.Text;

namespace UIproject.UI
{
	public class RichTextFormatPage : Page
	{
		public RichTextFormatPage(string fileName)
		{
			throw new NotImplementedException();
		}
	}
}
