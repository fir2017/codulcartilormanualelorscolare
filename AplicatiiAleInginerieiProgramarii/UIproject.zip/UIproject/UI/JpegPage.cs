using System;
using System.Collections.Generic;
using System.Text;

namespace UIproject.UI
{
	public class JpegPage : Page
	{
		public JpegPage(string fileName)
		{
			throw new NotImplementedException();
		}
	}
}
