using System;
using System.Collections.Generic;
using System.Text;

namespace UIproject.UI
{
	public class BitmapPage : Page
	{
		public BitmapPage(string fileName)
		{
			throw new NotImplementedException();
		}
	}
}
