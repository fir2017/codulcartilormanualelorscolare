using System;
using System.Collections.Generic;
using System.Text;

namespace UIproject.UI
{
	public class TextDocument : Document
	{
		public TextDocument(string indexFileName)
		{
			throw new NotImplementedException();
		}

		public override Page CreatePage(string fileName)
		{
			throw new NotImplementedException();
		}
	}
}
