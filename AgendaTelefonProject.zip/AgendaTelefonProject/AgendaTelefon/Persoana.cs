using System;
using System.Collections.Generic;
using System.Text;

namespace AgendaTelefonProject.AgendaTelefon
{
	public class Persoana
	{
		string nume;
		string prenume;
		string info;
		string detalii;
		string email;
		string adresa;
		int newField;
		GalerieDeImagini imagini;
	}
}
