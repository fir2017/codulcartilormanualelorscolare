using System;
using System.Collections.Generic;
using System.Text;

namespace AgendaTelefonProject.AgendaTelefon
{
	public class GalerieDeImagini
	{
		List <Image> Imagini;
		string denumire;
	}
}
