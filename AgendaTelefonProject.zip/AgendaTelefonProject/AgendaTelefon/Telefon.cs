using System;
using System.Collections.Generic;
using System.Text;

namespace AgendaTelefonProject.AgendaTelefon
{
	public class Telefon
	{
		NumarTelefon numardetelefonmobil;
		Persoana persoana;
		NumarTelefon numardetelefonfix;
		NumarTelefon numardetelefonmobilsecund;
	}
}
